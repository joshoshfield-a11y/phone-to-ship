# License terms template — NOT READY FOR DISTRIBUTION

**Replace this document with terms reviewed by a qualified lawyer before selling or redistributing this package.**

Copyright holder: [LEGAL NAME OR ENTITY]
Effective date: [DATE]
Product/version: Phone-to-Ship [VERSION]

Potential topics to decide explicitly: permitted number of users and devices; personal vs commercial use; modification and redistribution; resale and sublicensing; attribution; support and update obligations; warranty disclaimer; limitation of liability; termination; governing law; third-party components; refund policy; and treatment of customer data.

Do not claim ownership of third-party software, trademarks, documentation or generated content. Confirm that the distributor has rights to every included file before release.
