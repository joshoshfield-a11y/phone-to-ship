# Skill Playbook Template

Name: YOUR_SKILL_NAME
Use this when: YOUR_TRIGGER (the exact kind of job this playbook covers)
Do not use this when: YOUR_EXCLUSION

## What good looks like

YOUR_DONE_CRITERIA — how you know the job actually worked, not just that a command ran.

## Steps

1. YOUR_STEP_1
2. YOUR_STEP_2
3. YOUR_STEP_3

## Checks before you call it done

- [ ] YOUR_CHECK_1 (a test, a file size, a screenshot, a real-phone run — something verifiable)
- [ ] YOUR_CHECK_2

## Gotchas you already learned

- YOUR_GOTCHA_1 (what broke last time, and the fix)
- YOUR_GOTCHA_2

## What to hand back

YOUR_OUTPUT_FORMAT — the file, link, or report the user should actually receive.
