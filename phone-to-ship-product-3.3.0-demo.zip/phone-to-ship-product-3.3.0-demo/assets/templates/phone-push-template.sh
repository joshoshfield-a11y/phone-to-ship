#!/usr/bin/env bash
# Phone-to-Ship template: send a build file to your phone over SSH.
# Run on your build machine. Replace every YOUR_ placeholder first.
# Usage: ./02-phone-push-template.sh path/to/your-app.apk
set -e

PHONE_USER="YOUR_PHONE_USERNAME"
PHONE_HOST="YOUR_PHONE_HOST"
PHONE_PORT="8022"
PHONE_KEY="$HOME/.ssh/phone_lab_key"
REMOTE_DIR="/sdcard/Download"

FILE="${1:-}"
if [ -z "$FILE" ]; then
  echo "Usage: $0 path/to/build-file"
  exit 1
fi
if [ ! -f "$FILE" ]; then
  echo "File not found: $FILE"
  exit 1
fi
if [ "$PHONE_USER" = "YOUR_PHONE_USERNAME" ] || [ "$PHONE_HOST" = "YOUR_PHONE_HOST" ]; then
  echo "Stop: replace YOUR_PHONE_USERNAME and YOUR_PHONE_HOST first."
  exit 1
fi

echo "Sending $FILE to $REMOTE_DIR on your phone..."
scp -P "$PHONE_PORT" -i "$PHONE_KEY" "$FILE" "$PHONE_USER@$PHONE_HOST:$REMOTE_DIR/"
echo "Sent. Install it from your phone's Download folder and play it for real."
echo "Do not call it shipped until you have played it on the real device."
