# Decision Log — YOUR_PROJECT_NAME

Append-only. Never delete a bad entry; correct it with a new entry that names what it replaces.

## YYYY-MM-DD — YOUR_DECISION_TITLE
- Decision: YOUR_DECISION
- Made by: YOUR_NAME (in your own words, not assumed)
- Replaces / corrects: YOUR_PREVIOUS_ENTRY_OR_NONE
- Reason: YOUR_REASON
- Effect on the next ship: YOUR_EFFECT
