# Project Brief — YOUR_PROJECT_NAME

- **What it is (one sentence):** YOUR_ONE_SENTENCE
- **Who it is for:** YOUR_AUDIENCE
- **Core action / core loop:** YOUR_CORE_LOOP
- **Done condition (win / usable):** YOUR_DONE_CONDITION
- **Targets:** [ ] Web (Vercel)  [ ] Android APK  [ ] itch.io  [ ] Marketplace
- **Phone verdict device:** YOUR_PHONE_MODEL (no serial, no device ID)
- **Explicitly out of v1:** YOUR_OUT_OF_SCOPE (online multiplayer, server backend, accounts, real payments — unless ordered)
- **Assumptions:** YOUR_ASSUMPTIONS
- **Open choices (picked, not assumed):** YOUR_CHOICES
- **Skill checked first:** YOUR_SKILL_NAME_AND_PATH
