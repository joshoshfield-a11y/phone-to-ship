# Phone setup, done by hand each session

This stripped variant has no setup script. You do these steps yourself,
in Termux on your own phone, and you start the connection yourself each
time you want it. Nothing starts on its own, and nothing stays running
after you stop it.

## First time only

1. Install Termux from F-Droid or GitHub (the Play Store build is stale).
2. In Termux, update packages and install the SSH tools:
   `pkg update -y` then `pkg install -y openssh`
3. Run `termux-setup-storage` and tap Allow on the Android storage prompt.
   Without this, shared storage looks empty.
4. Make your own key pair on your build machine, if you do not have one:
   `ssh-keygen -t ed25519 -f ~/.ssh/phone_lab_key`
   Keep the private half on your build machine only. Never share it.
5. In Termux, create the key file by hand and paste in the public half
   only (the `.pub` file contents). Set its permissions to owner-only.
6. Note your Termux username from `whoami`. That is the one value a
   helper needs to connect, along with your phone's address on your
   own private network.

## Every session you want to use it

1. Open Termux on your phone.
2. Run `sshd` yourself.
3. Use the connection, then stop it when you are done.
4. After a phone reboot, repeat step 2. There is no automatic start.

## Sending a file to your phone

Use the phone-push template in this package. Replace every `YOUR_`
placeholder first. The template refuses to run while placeholders
remain. Send the file, then install and test it on the real phone.
A build nobody played on a real phone is built, not shipped.
