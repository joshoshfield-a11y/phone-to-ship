# Shipping Checklist — YOUR_PROJECT_NAME vYOUR_VERSION (YOUR_DATE)

## Before you build
- [ ] Direction confirmed in your own words, and what it is for
- [ ] Real choices picked (not assumed): ______________________
- [ ] Playbook checked: does a reusable skill already exist?
- [ ] Phone free space checked (storage full blocks installs)

## Build and test
- [ ] Headless tests green, no console errors that matter
- [ ] Smoke check passed (opens, main flow works, no crash on start)
- [ ] APK checked, if Android: signature, manifest, file intact, byte count noted
- [ ] Byte count / file size: ______________________
- [ ] ship-check.py run, result: ______________________

## Approval gate (do not skip)
- [ ] You approved the commit
- [ ] You approved the push
- [ ] You approved the publish / store listing / purchase, if any
- [ ] Nothing was merged, pushed, published, sent, or bought without your word

## Ship
- [ ] Web: push to main, Vercel deploy shows READY, live link opened on your phone
- [ ] Android: APK sent to the target device download folder (or verified link), installed from the phone
- [ ] Store: listing reviewed by eye before publishing, payout method connected first

## Real-phone verdict (this is the ship test)
- [ ] Played on a real phone, not just the sandbox
- [ ] Verdict form filled in (phone-verdict.md): Ship it / Fix and re-ship / Hold

## After
- [ ] Release notes written (what actually changed, with version + bytes)
- [ ] Decision log updated
- [ ] What broke, written down so the next ship is faster: ______________________
