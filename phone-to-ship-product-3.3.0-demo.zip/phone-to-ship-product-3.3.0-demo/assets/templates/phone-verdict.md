# Phone Verdict — YOUR_PROJECT_NAME vYOUR_VERSION

- Phone: YOUR_PHONE_MODEL (no serial, no device ID)
- Date: YOUR_DATE

## First impression (30 seconds in)
YOUR_NOTES

## Controls and feel
- Buttons big enough? [ ] Yes  [ ] No — details: ______________________
- Touch / stick feel: ______________________
- Anything annoying to reach? ______________________

## Performance on the real phone
- Smooth, or stuttering? ______________________
- Load time feel: ______________________
- Battery / heat, if noticeable: ______________________

## Bugs
1. What happened: ______________________
   Steps to make it happen again: ______________________
   Screenshot or clip attached? [ ] Yes  [ ] No

## Verdict
[ ] Ship it
[ ] Fix and re-ship (what must change first: ______________________)
[ ] Hold (why: ______________________)

One sentence for the builder:
YOUR_ONE_SENTENCE_VERDICT
