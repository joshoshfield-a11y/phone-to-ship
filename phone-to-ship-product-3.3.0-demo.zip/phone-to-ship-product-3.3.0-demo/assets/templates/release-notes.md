# Release Notes — YOUR_PROJECT_NAME vYOUR_VERSION

Date: YOUR_DATE

## What is new

- YOUR_CHANGE_1 (say what the user will actually notice)
- YOUR_CHANGE_2

## What got fixed

- YOUR_FIX_1 (what was broken, in plain words)
- YOUR_FIX_2

## What is still open

- YOUR_KNOWN_ISSUE_1 (honest, not hidden)
- YOUR_KNOWN_ISSUE_2

## How to get it

- Web: YOUR_LIVE_URL
- Android: install the APK from YOUR_DOWNLOAD_LOCATION, then play it on your phone
- Price / tier, if any: YOUR_PRICE_OR_FREE

## What I need from you

Play it on a real phone and tell me what felt wrong. Screenshots help more than a long description.
