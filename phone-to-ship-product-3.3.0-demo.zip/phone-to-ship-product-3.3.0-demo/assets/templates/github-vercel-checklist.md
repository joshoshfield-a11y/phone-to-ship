# GitHub + Vercel Starter Checklist

Use this for a new web project, from empty repo to live link.

## 1. Repo

- [ ] New repo created on GitHub: YOUR_REPO_URL
- [ ] Local project folder created, git initialized
- [ ] `.gitignore` added (see 06-gitignore-template.txt)
- [ ] First commit made, and pushed only after you reviewed it

## 2. Project shape

- [ ] Build command known: YOUR_BUILD_COMMAND (example: `npm run build`)
- [ ] Output folder known: YOUR_OUTPUT_FOLDER (example: `dist`)
- [ ] App folder known, if the app is not at the repo root: YOUR_APP_FOLDER
- [ ] App runs locally first, before any deploy is attempted

## 3. Vercel

- [ ] Project imported from GitHub into Vercel
- [ ] Root Directory set to: YOUR_APP_FOLDER (leave blank if the app is at the root)
- [ ] Framework preset set, if any: YOUR_FRAMEWORK
- [ ] Build Command set to: YOUR_BUILD_COMMAND
- [ ] Output Directory set to: YOUR_OUTPUT_FOLDER
- [ ] Environment variables added, if any (in the Vercel dashboard, never in the repo):
  - YOUR_ENV_VAR_NAME = (set in dashboard only)
- [ ] First deploy attempted, deploy log read, not just the green/red badge

## 4. If the deploy fails

- [ ] Root Directory checked first (this is the most common cause: it points at a folder that no longer exists)
- [ ] Build output folder checked against what the build actually produced
- [ ] A fresh deploy triggered after the fix, and checked to READY
- [ ] Live link opened on your phone, not just on desktop

## 5. After it is live

- [ ] Live URL written down: YOUR_LIVE_URL
- [ ] Future pushes to main auto-deploy, verified with one small change
- [ ] Admin / owner email set in the dashboard, if the platform needs one
