# Changelog

## 3.3.0-demo — Free demo cut from 3.3.0 (2026-11-21)

Free demo of phone-to-ship 3.3.0, core loop only. Agent orchestration
(`pts agents ...`) and Muse-loop AI import (`pts ai ...`) are cut;
both print a not-in-demo message and exit 2. Everything else —
scaffold, check, orchestrate, verdict, package, snapshots, config,
doctor — works as in 3.3.0. Full version $25.

## 3.3.0 — Agent orchestration, minimal and honest (2026-11-05)

The plan's "key differentiator", built as the shape that is real
today: `pts agents` runs seven roles (architect, code, asset, test,
build, deployment, qa) on one persistent queue under
`.pts/agent-runs/<run-id>/queue.json`, with a checkpoint after every
task transition, an append-only event log (`log.jsonl`, the message
bus), the tree inventory recorded at plan time (context/version
record), bounded re-runs of failed local checks
(`agents.max-retries`, config 0-3, default 2), and a human verdict
gate at the end. There is no live model inside the engine and no
auto-fix that edits files: code and asset work arrives as Muse-loop
replies — the engine writes a role-scoped prompt, the task waits in
`awaiting-reply`, `pts agents import` validates the reply through
the same safety core as `pts ai import` (write-only, in-tree, no
`.pts/`, caps), and `pts agents resume` continues from the
checkpoint. The deployment agent writes a plan the user runs by
hand; it deploys nothing. A run ends at `awaiting-approval` only
when qa verifies the staged manifest byte for byte, and
`pts agents verdict` records one decision, once. See
`scripts/agents/README.md` for what "multi-agent" honestly means
here. New tests 29–34 (8 checks); suite is now 38 checks at depth 0,
34 in the build gate. Installer pre-swap gate now compiles `scripts/`
recursively (the flat glob silently skipped `scripts/ai/` and the
new `scripts/agents/` package).

## 3.2.0 — AI provider integration, Muse loop first (2026-11-05)

One adapter working reliably, per the plan: the Muse loop.
`pts ai prompt` writes a structured prompt file (task, run plan and
failures, tree inventory, hard rules, JSON reply shape) under
`.pts/ai/<run-id>/prompt.md`; the user pastes it to Muse and saves
the JSON reply; `pts ai import` validates the reply against a shared
safety core (`scripts/ai/base.py`) and applies it as a proposal.
The core is provider-independent: write-only, in-tree relative paths
only, no `.pts/` writes, no deletes/moves/exec, 20-action / 200 KB
per-file / 1 MB total caps. A refused reply writes nothing. An
applied import is logged per file, recorded in run.json as paths +
byte counts only (never content), and changes no run status or
verdict — orchestrate + verdict still gate the ship decision.
`pts ai providers` reports muse-loop ready and openai-compat
planned, not built: a live HTTP adapter needs an API key stored on
the device, and no key exists anywhere in this environment — there
is deliberately no key-storage code in 3.2.0 (no `ai.api_key`
config key, no key in any ledger, prompt, or log). The contract a
future adapter must satisfy is written in `scripts/ai/README.md`.
New config key `ai.provider` (muse-loop | openai-compat). New tests
24–28 (providers, prompt, import, rejection cases, provider
refusals); suite is now 30 checks at depth 0, 26 in the build gate.
Build gate 2 now compiles `scripts/` recursively so the new
`scripts/ai/` package is covered.

## 3.1.0 — production hardening (2026-11-05)

Merge of the 3.0.0 line and the 1.2.0 line. Base is the 3.0.0 archive
(verified sha256 `a7f2d379b5a18f2b4aed864ae74ece8f6bc8ba78bff16513dbc1a1306592cfa5`);
the orchestration engine is merged in from the 1.2.0 tree. Merge
decisions, every one of them:
- Installer: 3.0.0's guarded transactional installer wins (stage,
  validate, backup, swap, guarded uninstall). Install directory
  changed from 3.0.0's `share/phone-to-ship` to
  `share/phone-to-ship-product` so an upgrade over a 1.2.0 install
  replaces the same tree instead of installing beside it; an old
  3.0.0-path install is detected and reported, not touched.
  Added: installed-version detection, post-install full self-test
  with rollback to the backup on failure, idempotent re-run,
  py_compile to /dev/null so the staged tree stays __pycache__-free.
- `ship-check.py`: 1.2.0's `.pts` skip wins (a quarantined `.py`
  file must not be re-flagged) and its fail-string format wins so
  orchestrate's classifier keeps working; 3.0.0's secret-pattern
  scan, symlink refusal, node-missing warning, and invalid-require
  check are merged in. The scan reports pattern labels and paths,
  never matched values.
- `package.py`: 3.0.0's containment/symlink/version guards win, with
  one exemption: a destination under the source tree's own `.pts/`
  is allowed, because that is where orchestrate stages packages.
  1.2.0's `.pts` input exclusion wins; 3.0.0's extra exclusions
  (node_modules, tests, __pycache__) are kept.
- `scaffold.py`: 1.2.0's full scaffold wins (templates, snapshots/,
  phases/, vercel.json, .gitignore, CHANGELOG/README); 3.0.0's
  project-name validation (1-100 printable), TEST-PLAN.md,
  SECURITY.md, and tests/ + docs/ directories are merged in.
  3.0.0's stale `termux-setup-template.sh` mapping is dropped — the
  template file does not exist in the archive.
- `validate_templates.py`: 1.2.0's version wins (per-template
  consumption check + secret patterns).
- `build_package.py`: 3.0.0's manifest-backed builder wins, with its
  test gate fixed — it invoked `unittest discover`, which matches no
  test file here, so the gate was vacuous; it now runs the real suite
  (`tests/run_tests.py`) and refuses to build on failure. It stages
  the full product tree (bin/, install.sh, uninstall.sh, VERSION,
  fixtures/, .github/ included — 3.0.0's builder staged only a
  whitelist and missed them). The manifest covers every staged file
  except itself.
- `bin/pts`: 1.2.0's subcommands (orchestrate, runs, verdict) plus
  3.0.0's doctor, extended into `scripts/doctor.py`, plus the new
  snapshot/restore/snapshots/config/logs subcommands.
- Tests: 3.0.0's 10-test suite and 1.2.0's 5 orchestrate tests are
  both kept (the 3.0.0 suite already covered nested-destination
  refusal and the secret scan; the 1.2.0 suite covered orchestrate,
  verdict, and brief fail-fast). New 3.1.0 tests cover doctor,
  snapshot/restore round-trip and corrupt-snapshot refusal, config
  validation and the orchestrate max-repairs default, structured
  run logs, the Termux harness, the upgrade-over-1.2.0 install, and
  the build gate refusing on a failing suite.
- Defect fixed: the 7 stray `__pycache__` .pyc files in the 3.0.0
  archive are removed. The 3.1.0 zip contains zero `__pycache__`
  entries (verified with `unzip -l`).

The 7 verified hardening items:
1. Android Termux testing — `scripts/termux-check.py`: validates the
   install under Termux-like conditions (no root / no privilege
   escalation, $PREFIX paths, python3 >= 3.9, graceful handling when
   termux-api is absent, simulated Termux-prefix install + doctor +
   validate). Honest limit: this proves the packaging is Termux-safe;
   a real-phone run is still the user's verdict.
2. Installer improvements — fresh install and upgrade over an
   existing install: version detection, backup before replace,
   post-install self-test with rollback, idempotent re-run.
3. Dependency detection — `pts doctor` extended: python3 version,
   bash, node, git, Termux detection, termux-api; missing-tool
   report with install hints; nonzero exit when a required tool is
   missing.
4. Recovery system — `pts snapshot` (manifest + hashes + copies
   under `.pts/snapshots/<id>/`), `pts restore` (hash-checks the
   snapshot before copying anything back, refuses a corrupt
   snapshot, verifies hashes after restore), `pts snapshots` list.
5. Configuration manager — `pts config` on `.pts/config.json`
   with validated keys (name, target, max-repairs, version);
   orchestrate reads max-repairs from it when --max-repairs is not
   given.
6. Logging system — structured per-run `.pts/runs/<run-id>/log.jsonl`
   (one JSON event per line, written by orchestrate and verdict;
   snapshot/restore/config write to the tree-level `.pts/ops.jsonl`),
   plus `pts logs --tree DIR --run ID`.
7. Automated CI testing — `.github/workflows/ci.yml` (GitHub
   Actions, runs the local gate on each push) and
   `scripts/ci-check.sh` (validate, full suite, Termux harness,
   clean install + installed-binary orchestrate on both fixtures,
   uninstall); `scripts/build_package.py` refuses to build when the
   suite fails.

## 3.0.0
- Unified v1.1 executable CLI, installer, demo fixtures, and regression suite with v2 architecture, documentation, and safer utilities.
- Added guarded transactional install/upgrade and guarded uninstall.
- Added `pts doctor` environment report.
- Added regression tests for nested package destinations and credential-pattern detection.
- Improved release documentation and compatibility guidance.

## 2.0.0
- Portable skill architecture, security and release documentation improvements.

## 1.2.0 — orchestration engine (2026-11-05)
- New `scripts/orchestrate.py` (stdlib only, no network): a run state
  machine — brief -> plan -> build -> test -> diagnose -> repair
  (bounded) -> package -> approval-stop -> verdict (separate
  command) — that shells out to the existing scaffold, ship-check,
  and package scripts instead of re-implementing their checks.
- New `pts` subcommands: `orchestrate --tree DIR --brief FILE
  [--max-repairs N]` (default 3), `runs --tree DIR`,
  `verdict --tree DIR --run ID --decision ship|fix|hold [--note ...]`.
- Brief validation fails fast (exit 2), naming exactly which field
  is missing: project name, goal, or target (web/apk).
- Repair rules: the only automatic repair is quarantining leaked
  files to `.pts/quarantine/<run-id>/`, preserving relative paths,
  never deleting. Missing files are never fabricated, JS is never
  auto-edited, placeholders are never touched.
- Approval gate: a passing run is staged under
  `.pts/staged/<run-id>/` with status `awaiting-approval` and stops.
  A verdict only records the human decision; a second verdict on
  the same run, or a verdict on a `needs-human` run, is refused
  (exit 2). Nothing is merged, pushed, published, sent, or bought.
- Run ledger: `.pts/runs/<run-id>/plan.json` and `run.json` with an
  append-only stage history, plus `runs/index.json` listing all
  runs. `.pts/` is orchestration bookkeeping, not package content:
  ship-check.py and package.py both skip it now, so a quarantined
  `.py` file is not re-flagged and ledgers are never shipped inside
  a staged package.
- Tests: orchestrate coverage added to `tests/run_tests.py` —
  good tree to `awaiting-approval` with a staged package, bad tree
  quarantine + `needs-human` exit 1 with no package staged,
  verdict success / double-verdict refusal / needs-human refusal,
  and brief-missing-goal fail-fast exit 2.

## 1.1.0
- Initial product CLI, installer, demo fixtures, and regression tests.
