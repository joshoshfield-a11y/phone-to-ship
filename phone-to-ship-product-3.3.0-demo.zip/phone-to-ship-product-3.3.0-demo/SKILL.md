---
name: phone-to-ship
description: "A repeatable, approval-gated workflow for planning, building, testing, packaging and releasing software from a phone or other constrained device, using a persistent local or cloud workspace."
---

# Phone-to-Ship

A practical idea-to-release workflow: **brief → build → test → review → approve → release → verify on the target device → iterate.** A phone can be the control surface; a persistent local or cloud workspace performs heavier builds. Adapt tools and paths to the user's actual environment rather than assuming a specific device, account, provider, or directory layout.

## Operating principles

- Keep durable projects in a persistent workspace and scratch files in a location with sufficient capacity.
- Prefer reproducible scripts and local checks over repeated manual steps.
- Inspect existing project structure before creating or changing files.
- Preserve known-good states with backups or version control before risky operations.
- Avoid destructive synchronization and recursive deletion unless the exact target is verified and the user explicitly approves.
- Use least privilege. Keep credentials in a secure local secret store; never place them in prompts, logs, source control, client-side bundles, or release archives.
- Treat generated artifacts as candidates until they pass the relevant platform checks and real-device verification.

## Step 0 — Brief before build

Create a concise project brief using `assets/templates/project-brief.md`. Record the intended audience, core user journey, success condition, target platforms, constraints, assumptions, and what is out of scope. Ask only the question that blocks progress when a material decision is unresolved.

## Step 1 — Prepare the workspace

Identify the actual device, operating system, shell, persistent storage, available SDKs, and network constraints. Prefer a stable workspace directory and document setup commands. Do not assume that a phone has unrestricted filesystem access or that a cloud workspace persists across resets. Keep dependencies and build tools versioned where practical.

## Step 2 — Build and test

- Use staged asset and code directories; do not write experimental outputs directly into a known-good release tree.
- Run the project's automated tests and platform-appropriate headless checks.
- Check error states, empty states, accessibility basics, touch interaction, and responsive layouts where relevant.
- Inspect dependencies, licenses, permissions, secrets, and packaged files.
- Record commands, environment versions, results, skipped checks, and known defects.

See `references/build-and-test.md` for target-specific guidance.

## Step 3 — Connect phone and workspace safely

Choose an appropriate handoff: private-network SSH, browser-based cloud IDE, Git workflow, USB debugging/ADB, or a platform-specific transfer. Prefer key-based authentication for SSH, verify host keys, restrict network exposure, and use least-privilege access. On Android, shared-storage access requires explicit permission and does not grant access to other apps' private data.

For transferred artifacts, record source and destination, byte count, and SHA-256 where possible. Verify the received artifact before installing or replacing a known-good copy. See `references/phone-bridge.md`.

## Step 4 — Package and release by target

- **Web:** verify build command, output directory, routes, headers, environment variables, HTTPS, mobile layout, and rollback plan. Never embed secrets in client-side bundles.
- **Android:** verify package identity, manifest, permissions, signing identity, release build type, clean installation, update behavior, and target-device compatibility. Protect signing keys and backups.
- **Desktop / other platforms:** validate the platform's packaging, signing, permissions, update, and distribution requirements against current official documentation.
- **Stores and portals:** review listing content, assets, privacy disclosures, content ratings, pricing, regional requirements, support, and refund policies.

Do not commit, push, merge, deploy, submit, publish, send announcements, purchase services, or change pricing without explicit user approval for the specific action. See `references/publish.md`.

## Step 5 — Verify on the target device

A successful compile or upload is not proof that the product works. Install or open the exact release candidate on the intended device and test the primary user journey, controls, performance, permissions, network behavior, and recovery from failure. Record device/OS, build identifier, date, evidence, defects, and a verdict: **Ship it / Fix and re-ship / Hold** using `assets/templates/phone-verdict.md`.

## Step 6 — Close the loop

Write release notes, update the decision log, preserve the artifact and manifest, and convert lessons into reusable tests or documentation. Never delete failed attempts or staging evidence until the replacement is verified and the user approves cleanup.

## Local utility commands

The bundled `pts` CLI supports `new`, `check`, `package`, `validate`, `self-test`, `doctor`, and `version`. These commands create and inspect local files only. They do not perform remote publishing or other consequential actions. See `README.md` and `INSTALL.md`.

## Orchestration (v1.2.0 engine, kept in 3.1.0, 3.2.0, and 3.3.0)

`pts orchestrate --tree DIR --brief FILE [--max-repairs N]` runs a
built tree through brief → plan → build (inventory only) → test →
diagnose → repair (bounded) → package → approval-stop. The only
automatic repair is quarantining leaked files to
`.pts/quarantine/<run-id>/`, preserving relative paths, never
deleting. Missing files are never fabricated, JS is never auto-edited,
placeholders are never touched. A passing run is staged under
`.pts/staged/<run-id>/` with status `awaiting-approval` and stops.
`pts runs --tree DIR` lists runs; `pts verdict --tree DIR --run ID
--decision ship|fix|hold [--note "..."]` records the human decision
on an `awaiting-approval` run only (a second verdict, or a verdict on
a `needs-human` run, is refused). A verdict records a decision; it
does not publish, push, or ship anything.

Every run writes `.pts/runs/<run-id>/plan.json`, `run.json`
(append-only stage history), `log.jsonl` (one JSON event per line per
stage), and `runs/index.json`. `pts logs --tree DIR --run ID` prints
the run log. `--max-repairs` defaults to the tree's
`.pts/config.json` `max-repairs` when set, otherwise 3.

## Snapshots, config, and environment checks (3.1.0)

- `pts snapshot --tree DIR` records the tree's known-good state
  (file manifest + hashes + copies) under
  `.pts/snapshots/<id>/`. `pts snapshots --tree DIR` lists them.
  `pts restore --tree DIR --id ID` restores one: the snapshot is
  hash-checked against its manifest before anything is copied back,
  and a corrupt snapshot is refused; hashes are verified again after
  restore. Files created after the snapshot are left in place.
- `pts config --tree DIR [get KEY | set KEY VALUE]` reads/writes
  `.pts/config.json`. Valid keys: `name`, `target` (web/apk/web,apk),
  `max-repairs` (0-10), `version` (e.g. 3.3.0).
  Invalid keys and values are refused with a clear error.
- `pts doctor` reports python3 (required, >= 3.9), bash (required),
  node (optional), git (optional), Termux detection, and termux-api
  (optional, absence handled gracefully). Exit 1 when a required
  tool is missing, with an install hint.
- `scripts/termux-check.py` proves the packaging is Termux-safe
  (no root, $PREFIX paths, graceful termux-api absence, simulated
  Termux-prefix install). It does not prove real-phone behavior —
  that run is still the user's verdict on their own device.
- `scripts/ci-check.sh` (and `.github/workflows/ci.yml`) run the
  release gates: validate, full suite, Termux harness, clean install
  + installed-binary orchestrate on both fixtures, uninstall.
  `scripts/build_package.py` refuses to build when any gate fails.

## Free demo — what's not included

Agent orchestration (`pts agents ...`) and Muse-loop AI import
(`pts ai ...`) are cut from this free demo; both print
`not included in the free demo — full version only ($25)` and exit 2.
The full version is $25 at
https://buy.stripe.com/dRm28rbjx3VbeyR3Kj2wU00.

## References

- `references/architecture.md` — workflow boundaries and workspace architecture
- `references/phone-bridge.md` — secure phone/workspace connection patterns
- `references/build-and-test.md` — build and test gates
- `references/publish.md` — release and distribution checks
- `references/troubleshooting.md` — common environment and build failures
- `references/verdict-and-loop.md` — device verdict and iteration process
