# Phone-to-Ship v3.3.0 — installation

## Install the CLI

On Linux, macOS, or Termux with Bash and Python 3.9+:

```bash
./install.sh
pts doctor
pts self-test
```

The installer stages and validates a copy before replacing a previous managed installation, backs up the old tree, and re-runs the full self-test on the installed copy (restoring the backup if that test fails). The default prefix is `~/.local` (installs to `~/.local/share/phone-to-ship-product`, command `~/.local/bin/pts`); set `PTS_PREFIX` or pass a prefix argument to use another location. Ensure `<prefix>/bin` is on `PATH`. Re-running install.sh is idempotent. Upgrading over a 1.2.0 install replaces the same tree; an older install at `~/.local/share/phone-to-ship` (the 3.0.0 path) is reported, not touched — remove it with its own uninstall.sh.

To remove the managed installation:

```bash
./uninstall.sh
```

The uninstaller verifies the managed symlink and installation marker (VERSION + bin/pts + PACKAGE-MANIFEST.json) before deleting anything. It does not remove project directories.

## Use the skill without installing the CLI

Copy `SKILL.md`, `skill.yaml`, `references/`, `assets/`, `scripts/`, and `docs/` into the skill directory supported by your AI environment. Run `python3 scripts/validate_templates.py --skill .` to validate templates.

## Requirements

- Python 3.9+ for the CLI and utilities.
- Bash for install/uninstall and shell templates.
- Node.js is optional; JavaScript syntax checks are skipped with a warning when Node.js is unavailable.

## After install

- `pts doctor` — environment report with missing-tool hints.
- `pts self-test` — full automated suite.
- `python3 scripts/termux-check.py` — Termux compatibility harness (proves the packaging is Termux-safe; a real-phone run is still your verdict).
- `bash scripts/ci-check.sh` — the local CI gate (validate, suite, Termux harness, clean install + installed-binary orchestrate, uninstall).

The toolkit does not automatically publish, deploy, submit, send, purchase, or change production systems. Obtain explicit approval for each consequential action. Review `LICENSE-TERMS-TEMPLATE.md` with qualified counsel and replace placeholders before commercial distribution.
