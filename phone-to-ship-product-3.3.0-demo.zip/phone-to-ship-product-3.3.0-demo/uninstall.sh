#!/usr/bin/env bash
# Guarded uninstall. Projects created with pts are never touched.
# Removes only the managed install at $PREFIX/share/phone-to-ship-product
# and the managed $PREFIX/bin/pts symlink, and only when both are
# verified to be this product's (VERSION + bin/pts + PACKAGE-MANIFEST.json
# marker files present). Anything else is left alone and the uninstall
# is refused with exit 2.
set -Eeuo pipefail
PREFIX="${1:-${PTS_PREFIX:-$HOME/.local}}"
case "$PREFIX" in ""|/|"$HOME"|"$HOME/..") echo "Refusing unsafe prefix: $PREFIX" >&2; exit 2;; esac
DEST="$PREFIX/share/phone-to-ship-product"
BIN="$PREFIX/bin/pts"
if [[ -L "$BIN" ]]; then
  TARGET="$(readlink "$BIN")"
  if [[ "$TARGET" == "$DEST/bin/pts" ]]; then rm -- "$BIN"; echo "Removed managed command link.";
  else echo "Leaving unrelated symlink untouched: $BIN -> $TARGET" >&2; exit 2; fi
elif [[ -e "$BIN" ]]; then
  echo "Leaving non-symlink command untouched: $BIN" >&2; exit 2
fi
if [[ -d "$DEST" && ! -L "$DEST" ]]; then
  # Verify a product marker before recursive deletion.
  if [[ -f "$DEST/VERSION" && -f "$DEST/bin/pts" && -f "$DEST/PACKAGE-MANIFEST.json" ]]; then
    rm -rf -- "$DEST"; echo "Removed managed installation."
  else echo "Refusing to remove unrecognized directory: $DEST" >&2; exit 2; fi
fi
echo "Uninstalled. Your projects and other files were left untouched."
