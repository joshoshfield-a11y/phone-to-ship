# Phone-to-Ship 3.3.0 — tested, turnkey developer automation

Ship software from a phone: phone as control surface, a persistent
workspace as workshop, GitHub as spine, Vercel / itch / phone as the
closing loop, with an approval gate and a real-phone verdict.

This product is a CLI tool plus the agent skill it came from. You can
use it with no agent in the loop.

## Install

```
./install.sh
```

That stages the product, validates it, backs up any existing install,
swaps it in, and re-runs the full self-test on the installed copy
(restoring the backup if that test fails). It installs to
`~/.local/share/phone-to-ship-product` and links `~/.local/bin/pts`.
Make sure `~/.local/bin` is on your PATH. Re-running install.sh on an
already-installed copy is idempotent. To remove it, run
`./uninstall.sh` — it verifies the install marker before deleting
anything. Projects you scaffolded are untouched by uninstall.

Requirements: python3 >= 3.9 is required. Node is needed only for JS
syntax checks in `pts check` (its absence is a warning, not a
failure). Bash is needed for install/uninstall and the shell
templates.

## Quickstart

```
pts self-test
pts new --name "My Game" --out ./my-game --target web
# put your built web tree into ./my-game, write a brief (see below)
pts orchestrate --tree ./my-game --brief ./brief.md
pts runs --tree ./my-game
pts verdict --tree ./my-game --run <run-id> --decision ship --note "played it, ships"
```

`pts self-test` runs the full automated suite and prints PASS/FAIL
per test. A clean install should pass every test before you trust it.

## Commands

- `pts new --name NAME --out DIR [--target web] [--target apk]` —
  scaffold a project with every working template.
- `pts check --tree DIR` — readiness gate: required files, JS syntax,
  excluded inputs, symlinks, credential-shaped values, file count,
  bytes, hashes. Exit 1 on a fail.
- `pts package --tree DIR --out DIR [--version V]` — stage a clean
  deliverable with MANIFEST.json and a phone checklist.
- `pts orchestrate --tree DIR --brief FILE [--max-repairs N]` —
  run the tree through brief -> plan -> build -> test -> diagnose ->
  repair (bounded, default 3, or `.pts/config.json` max-repairs) ->
  package -> approval-stop. Exit 0 with status `awaiting-approval`
  and a staged package, or exit 1 with status `needs-human` and
  every remaining fail printed.
- `pts runs --tree DIR` — list recorded runs: id, status, stage
  reached, fail count.
- `pts verdict --tree DIR --run ID --decision ship|fix|hold
  [--note "..."]` — record the human decision on an
  `awaiting-approval` run. A second verdict, or a verdict on a
  `needs-human` run, is refused. A verdict records a decision only;
  it does not publish, push, or ship anything.
- `pts logs --tree DIR --run ID` — print the structured run log
  (one JSON event per line per stage, stored at
  `.pts/runs/<run-id>/log.jsonl`).
- `pts snapshot --tree DIR` — record the tree's known-good state
  under `.pts/snapshots/<id>/`. `pts snapshots --tree DIR` lists
  them. `pts restore --tree DIR --id ID` restores one, refusing a
  corrupt snapshot and verifying hashes after restore.
- `pts config --tree DIR [get KEY | set KEY VALUE]` — project
  settings in `.pts/config.json`. Valid keys: `name`, `target`
  (web/apk/web,apk), `max-repairs` (0-10), `version` (e.g. 3.3.0).
  Invalid keys and values are refused.
- `pts doctor` — environment report: python3 (>= 3.9, required),
  bash (required), node (optional), git (optional), Termux detection,
  termux-api (optional, absence handled gracefully). Exit 1 when a
  required tool is missing, with an install hint.
- `pts validate` — prove the templates are clean: no real secret
  material, shell templates pass bash syntax checks and refuse to
  run with placeholders intact, vercel.json parses.
- `pts self-test` — the full suite, including a good tree that must
  pass and a bad tree that must fail on both expected fails.
- `pts version` — print the product version.

## Free demo — what's not included

This is the free demo cut of phone-to-ship 3.3.0. The core loop is
here — scaffold, check, orchestrate, verdict, package, snapshots —
but two subsystems are cut:

- Agent orchestration (`pts agents ...`): the 7-agent plan/run/resume
  queue and its replay board are not included.
- Muse-loop AI import (`pts ai ...`): structured prompts and JSON
  reply imports are not included.

Both print `not included in the free demo — full version only ($25)`
and exit 2. The full version is $25 at
https://buy.stripe.com/dRm28rbjx3VbeyR3Kj2wU00.

## Orchestrate: the brief, the repairs, the gate

A brief is a markdown file with three required fields, one per line:

```
Project: My Game
Goal: A playable web build I can verdict on my phone.
Target: web
```

`Target` is `web`, `apk`, or both. If any field is missing,
`pts orchestrate` fails fast (exit 2) and prints exactly which
field is missing. Nothing is created for a bad brief.

Repair rules: the only automatic repair is quarantining leaked
files — an excluded input such as a `*.py` file, or anything under
`raw/` or `phases/`, is moved to `.pts/quarantine/<run-id>/`
preserving its relative path. It is never deleted. Missing files
are never fabricated (no stub `index.html`), JS is never
auto-edited, placeholders are never touched. Each repair attempt
quarantines the leaked files found by that test, then re-tests;
after `--max-repairs` attempts (default 3) the run stops as
`needs-human` with every remaining fail printed verbatim.

Every run records `.pts/runs/<run-id>/plan.json` (stages,
max-repairs, stop conditions) and `run.json` (append-only stage
history: stage, timestamps, exit code, fails, repairs), plus
`runs/index.json` listing all runs and `log.jsonl` (one JSON event
per line per stage). `.pts/` is orchestration bookkeeping, not
package content, and is never shipped inside a staged package.

## The approval gate, in plain words

Nothing in this product merges, pushes, publishes, sends, or buys
anything. Those steps still need your word every time. A build nobody
played on a real phone is built, not shipped: the verdict is Ship it,
Fix and re-ship, or Hold, plus one sentence for the builder.

## Honest limits

`pts check`, `pts package`, and `pts orchestrate` prove file-level
readiness only. They do not prove an APK signature, a Vercel READY
deploy, or real-phone feel. Those are separate gates, reported
separately. A run that reaches `awaiting-approval` is ready for a
human verdict — it is not shipped.

`scripts/termux-check.py` proves the packaging is Termux-safe (no
root, $PREFIX paths, graceful termux-api absence, simulated
Termux-prefix install). It does not prove the product works on a
real phone — that run is still your verdict on your own device.

Templates carry YOUR_ placeholders only. Search for YOUR_ in a
scaffolded project and replace each one with your own value before
running any shell template. The shell templates refuse to run while
placeholders remain.

Phone connection setup is intentionally documented rather than silently automated. Follow `assets/templates/termux-manual-steps.md` and the security guidance in `references/phone-bridge.md` for your chosen environment.

## Price and listing

Not set in this build. Price, license, and where this is listed are
the owner's decision. Building this product does not publish or list
it anywhere.

## v3.1.0 production hardening

- Merged the 3.0.0 line (guarded transactional installer, `pts
  doctor`, secret-pattern scanning, docs) with the 1.2.0 line
  (orchestration engine, run ledgers, approval gate). Where they
  conflicted, the guarded installer won and the orchestration engine
  won; `package.py` refuses source/destination overlap except for
  the orchestration staging area under the tree's own `.pts/`, and
  `ship-check.py` keeps the secret scan while skipping `.pts/`
  entirely. See CHANGELOG.md for the full merge record. The 7 stray
  `__pycache__` .pyc files in the 3.0.0 archive are gone; the 3.1.0
  zip contains zero `__pycache__` entries.
- Termux compatibility harness (`scripts/termux-check.py`).
- Installer improvements: version detection, backup before replace,
  post-install self-test with rollback, idempotent re-run.
- Dependency detection: `pts doctor` now checks python3 >= 3.9,
  bash, node, git, Termux detection, and termux-api, with install
  hints and a nonzero exit when a required tool is missing.
- Recovery system: `pts snapshot` / `pts restore` / `pts snapshots`.
- Configuration manager: `pts config` on `.pts/config.json`, with
  validated keys; orchestrate reads `max-repairs` from it.
- Logging system: structured per-run `log.jsonl` plus `pts logs`.
- Automated CI: `.github/workflows/ci.yml` plus local
  `scripts/ci-check.sh`; `scripts/build_package.py` refuses to build
  when the suite fails.

See `docs/COMPATIBILITY.md`, `docs/ONBOARDING.md`, and
`docs/RELEASE-CHECKLIST.md`.

## Contents

SKILL.md and skill.yaml (the agent skill), references/, scripts/,
assets/templates/, docs/, bin/pts, tests/, fixtures/,
.github/workflows/ci.yml, install.sh, uninstall.sh, README.md,
CHANGELOG.md, VERSION, PACKAGE-MANIFEST.json, INSTALL.md,
LICENSE-TERMS-TEMPLATE.md.
