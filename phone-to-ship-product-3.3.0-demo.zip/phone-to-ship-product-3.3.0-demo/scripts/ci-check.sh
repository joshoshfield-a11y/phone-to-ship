#!/usr/bin/env bash
# Local CI gate: runs the same checks as .github/workflows/ci.yml.
# Usage: ./scripts/ci-check.sh
# Gates, in order:
#   1. validate_templates.py (0 fails)
#   2. Full automated suite (pts self-test)
#   3. Termux compatibility harness (scripts/termux-check.py)
#   4. Clean-install test: install to a temp prefix, check the
#      installed pts version + doctor, run orchestrate on copies of
#      both fixtures (good -> exit 0, bad -> exit 1), then uninstall
#      and verify the prefix is clean.
# Exit 0 only when every gate passes. Uses a temp prefix under home
# disk (never /tmp — it is a 512 MB tmpfs). Stdlib + bash only.
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PREFIX="$HOME/.local/pts-ci-$$"
cleanup(){ rm -rf -- "$PREFIX"; }
trap cleanup EXIT
echo "== ci gate 1: validate =="
"$ROOT/bin/pts" validate
echo "== ci gate 2: self-test =="
"$ROOT/bin/pts" self-test
echo "== ci gate 3: termux-check =="
python3 "$ROOT/scripts/termux-check.py" --product "$ROOT"
echo "== ci gate 4: clean install + installed-binary orchestrate =="
"$ROOT/install.sh" "$PREFIX"
INSTALLED="$PREFIX/bin/pts"
VERSION="$("$INSTALLED" version)"
if [[ "$VERSION" != "$(cat "$ROOT/VERSION")" ]]; then
  echo "ci: installed version '$VERSION' != product version '$(cat "$ROOT/VERSION")'" >&2
  exit 1
fi
echo "ci: installed version $VERSION"
"$INSTALLED" doctor
WORK="$PREFIX/work"
mkdir -p "$WORK"
cp -r "$ROOT/fixtures/demo-good" "$WORK/good"
cp -r "$ROOT/fixtures/demo-bad" "$WORK/bad"
"$INSTALLED" orchestrate --tree "$WORK/good" --brief "$ROOT/fixtures/demo-brief.md"
"$INSTALLED" runs --tree "$WORK/good"
if "$INSTALLED" orchestrate --tree "$WORK/bad" --brief "$ROOT/fixtures/demo-brief.md"; then
  echo "ci: bad fixture orchestrate should have failed" >&2
  exit 1
fi
echo "ci: bad fixture correctly failed"
"$ROOT/uninstall.sh" "$PREFIX"
if [[ -e "$PREFIX/share/phone-to-ship-product" || -e "$PREFIX/bin/pts" ]]; then
  echo "ci: uninstall left files behind" >&2
  exit 1
fi
trap - EXIT
rm -rf -- "$PREFIX"
echo "ci: ALL GATES PASS"
