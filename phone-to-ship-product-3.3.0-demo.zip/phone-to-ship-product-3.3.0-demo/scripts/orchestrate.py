#!/usr/bin/env python3
"""Phone-to-ship orchestration engine. Stdlib only, no network.

Runs a built tree through the existing scripts as a state machine:

    brief -> plan -> build -> test -> diagnose -> repair (bounded)
          -> package -> approval-stop -> verdict (separate command)

Usage (via `pts`):
  pts orchestrate --tree DIR --brief FILE [--max-repairs N]
  pts runs --tree DIR
  pts verdict --tree DIR --run ID --decision ship|fix|hold [--note "..."]
  pts logs --tree DIR --run ID
--max-repairs defaults to .pts/config.json max-repairs when set,
otherwise 3.

Rules, enforced here, not just documented:
- The brief must name a project, a goal, and a target (web/apk). A
  missing field fails fast with exit 2, naming the field.
- The ONLY automatic repair is quarantining leaked files: move them
  to .pts/quarantine/<run-id>/ preserving relative paths, never
  delete. Never fabricate missing files (no stub index.html), never
  auto-edit JS, never touch placeholders.
- A run that passes check is staged with package.py and stops at
  `awaiting-approval`. A verdict only records a human decision; it
  does not publish, push, or ship anything.
- Every run writes .pts/runs/<run-id>/plan.json and run.json under
  the tree, plus runs/index.json. Stage history only ever appends.
- Every stage also writes one JSON event per line to
  .pts/runs/<run-id>/log.jsonl (see scripts/runlog.py); `pts logs`
  prints that log. A verdict appends its own event to the same log.
- --max-repairs defaults to the tree's .pts/config.json max-repairs
  when set (see scripts/config.py), otherwise 3.
- .pts/ is orchestration bookkeeping, not package content:
  ship-check.py and package.py both skip it (see those scripts).

Honest limit: orchestrate proves file-level readiness only. It does
not prove APK signature, Vercel READY, or real-phone feel.
"""
import argparse, json, re, secrets, shutil, subprocess, sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import runlog  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
STAGES = ["brief", "plan", "build", "test", "diagnose", "repair",
          "package", "approval-stop", "verdict"]
STOP_CONDITIONS = ["check passes", "no repairable fails remain",
                   "max repairs exhausted"]
ALLOWED_REPAIRS = ["quarantine leaked files to .pts/quarantine/<run-id>/"]
FORBIDDEN_REPAIRS = ["fabricate missing files", "edit JS files",
                     "touch placeholders", "delete files"]


def utcnow():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def new_run_id():
    return (datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
            + "-" + secrets.token_hex(2))


def parse_brief(text):
    """Return (fields, missing). Fields: name, goal, target."""
    fields = {}
    m = re.search(r"(?im)^\s*(?:project|name)\s*:\s*(.+?)\s*$", text)
    if m and m.group(1).strip():
        fields["name"] = m.group(1).strip()
    else:
        m = re.search(r"(?im)^\s*#\s+(.+?)\s*$", text)
        if m and m.group(1).strip():
            fields["name"] = m.group(1).strip()
    m = re.search(r"(?im)^\s*goal\s*:\s*(.+?)\s*$", text)
    if m and m.group(1).strip():
        fields["goal"] = m.group(1).strip()
    m = re.search(r"(?im)^\s*targets?\s*:\s*(.+?)\s*$", text)
    if m:
        raw = m.group(1).strip().lower()
        found = [t for t in ("web", "apk") if t in raw]
        if found:
            fields["target"] = ",".join(found)
    missing = [f for f in ("name", "goal", "target") if f not in fields]
    return fields, missing


def runs_dir(tree):
    return Path(tree) / ".pts" / "runs"


def load_run(tree, run_id):
    path = runs_dir(tree) / run_id / "run.json"
    if not path.is_file():
        return None
    return json.loads(path.read_text())


def save_run(tree, run_id, ledger):
    ledger["updated"] = utcnow()
    path = runs_dir(tree) / run_id / "run.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(ledger, indent=2))
    return path


def record_stage(tree, run_id, ledger, stage, started, exit_code,
                 fails=None, repairs=None):
    ledger["stages"].append({
        "stage": stage, "started": started, "finished": utcnow(),
        "exit_code": exit_code, "fails": fails or [],
        "repairs": repairs or []})
    ledger["stage_reached"] = stage
    save_run(tree, run_id, ledger)


def update_index(tree):
    """Rebuild runs/index.json from every run ledger on disk."""
    entries = []
    base = runs_dir(tree)
    if base.is_dir():
        for run_file in sorted(base.glob("*/run.json")):
            try:
                ledger = json.loads(run_file.read_text())
            except (ValueError, OSError):
                continue
            entries.append({
                "run_id": ledger.get("run_id"),
                "status": ledger.get("status"),
                "stage_reached": ledger.get("stage_reached"),
                "fails": len(ledger.get("fails", [])),
                "created": ledger.get("created"),
                "updated": ledger.get("updated")})
    entries.sort(key=lambda e: e.get("created") or "")
    index = {"runs": entries}
    (base / "index.json").write_text(json.dumps(index, indent=2))
    return index


def run_ship_check(tree):
    r = subprocess.run([sys.executable, str(SCRIPTS / "ship-check.py"),
                        "--tree", str(tree)],
                       capture_output=True, text=True)
    report = {"fails": [], "warnings": []}
    start = r.stdout.find("{")
    end = r.stdout.rfind("}")
    if start >= 0 and end > start:
        try:
            report = json.loads(r.stdout[start:end + 1])
        except ValueError:
            pass
    return r.returncode, r.stdout, report


def classify_fail(fail):
    """Classify one ship-check fail string."""
    if fail.startswith("missing required file:"):
        return {"fail": fail, "kind": "missing-file",
                "path": fail[len("missing required file:"):].strip()}
    if fail.startswith("excluded input in package tree:"):
        return {"fail": fail, "kind": "leaked-file",
                "path": fail[len("excluded input in package tree:"):].strip()}
    if fail.startswith("syntax:"):
        rest = fail[len("syntax:"):].strip()
        return {"fail": fail, "kind": "js-syntax",
                "path": rest.split(":")[0].strip()}
    if fail.startswith("empty tree"):
        return {"fail": fail, "kind": "empty-tree", "path": None}
    return {"fail": fail, "kind": "unknown", "path": None}


def config_max_repairs(tree):
    """max-repairs from .pts/config.json, or None when unset/invalid."""
    path = Path(tree) / ".pts" / "config.json"
    if not path.is_file():
        return None
    try:
        value = json.loads(path.read_text()).get("max-repairs")
    except (ValueError, OSError):
        return None
    return value if isinstance(value, int) and 0 <= value <= 10 else None


def cmd_orchestrate(args):
    tree = Path(args.tree).expanduser().resolve()
    brief_path = Path(args.brief).expanduser()
    if not tree.is_dir():
        print(f"tree {tree} is not a directory", file=sys.stderr)
        return 2
    if not brief_path.is_file():
        print(f"brief {brief_path} is not a file", file=sys.stderr)
        return 2
    text = brief_path.read_text()
    fields, missing = parse_brief(text)
    if missing:
        for f in missing:
            print(f"missing brief field: {f}")
        return 2
    max_repairs = args.max_repairs
    if max_repairs is None:
        max_repairs = config_max_repairs(tree)
        if max_repairs is None:
            max_repairs = 3
        else:
            print(f"max-repairs: {max_repairs} (from .pts/config.json)")

    run_id = new_run_id()
    run_dir = runs_dir(tree) / run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    ledger = {"run_id": run_id, "tree": str(tree),
              "brief": str(brief_path), "project": fields["name"],
              "goal": fields["goal"], "target": fields["target"],
              "max_repairs": max_repairs, "status": "running",
              "fails": [], "repairs": [], "verdict": None,
              "created": utcnow(), "updated": utcnow(), "stages": []}
    save_run(tree, run_id, ledger)
    runlog.append_run_log(tree, run_id, "brief", "run-started",
                          f"{fields['name']} target={fields['target']} "
                          f"max-repairs={max_repairs}")

    # brief stage (validation already done above; record it)
    started = utcnow()
    record_stage(tree, run_id, ledger, "brief", started, 0)
    runlog.append_run_log(tree, run_id, "brief", "brief-validated",
                          fields["name"])

    # plan stage
    started = utcnow()
    plan = {"run_id": run_id, "project": fields["name"],
            "goal": fields["goal"], "target": fields["target"],
            "stages": STAGES, "max_repairs": max_repairs,
            "stop_conditions": STOP_CONDITIONS,
            "repairs_allowed": ALLOWED_REPAIRS,
            "repairs_forbidden": FORBIDDEN_REPAIRS,
            "tree": str(tree), "brief": str(brief_path),
            "created": utcnow()}
    (run_dir / "plan.json").write_text(json.dumps(plan, indent=2))
    record_stage(tree, run_id, ledger, "plan", started, 0)
    runlog.append_run_log(tree, run_id, "plan", "plan-written",
                          f"{len(STAGES)} stages")

    # build stage: orchestrate never builds code. It inventories the
    # existing tree and hands it to the existing check/package
    # scripts. Anything missing here is a fail, never a stub.
    started = utcnow()
    files = [p for p in tree.rglob("*")
             if p.is_file() and ".pts" not in p.relative_to(tree).parts]
    record_stage(tree, run_id, ledger, "build", started, 0)
    runlog.append_run_log(tree, run_id, "build", "build-inventoried",
                          f"{len(files)} files in tree, nothing fabricated")
    print(f"build: inventory only, {len(files)} files in tree, "
          f"nothing fabricated")

    # test -> diagnose -> repair loop (bounded by --max-repairs)
    repairs_done = 0
    fails = []
    diagnosis = []
    while True:
        started = utcnow()
        exit_code, _out, report = run_ship_check(tree)
        fails = report.get("fails", [])
        record_stage(tree, run_id, ledger, "test", started, exit_code,
                     fails=fails)
        runlog.append_run_log(tree, run_id, "test", "check-finished",
                              f"exit {exit_code}, {len(fails)} fail(s)")
        started = utcnow()
        diagnosis = [classify_fail(f) for f in fails]
        ledger["fails"] = fails
        record_stage(tree, run_id, ledger, "diagnose", started, 0,
                     fails=fails)
        runlog.append_run_log(
            tree, run_id, "diagnose", "diagnosis",
            ", ".join(sorted({d["kind"] for d in diagnosis}))
            or "no fails")
        if not fails:
            break
        leaked = [d for d in diagnosis if d["kind"] == "leaked-file"]
        if not leaked or repairs_done >= max_repairs:
            break
        # repair: one attempt quarantines every currently leaked file
        started = utcnow()
        attempt = {"attempt": repairs_done + 1, "action": "quarantine",
                   "files": []}
        for d in leaked:
            rel = d["path"]
            src = tree / rel
            dest = (tree / ".pts" / "quarantine" / run_id / rel)
            dest.parent.mkdir(parents=True, exist_ok=True)
            if src.is_file():
                shutil.move(str(src), str(dest))
                attempt["files"].append(
                    {"file": rel, "quarantined_to": str(dest)})
                print(f"repair: quarantined {rel} -> "
                      f".pts/quarantine/{run_id}/{rel}")
        repairs_done += 1
        ledger["repairs"].append(attempt)
        record_stage(tree, run_id, ledger, "repair", started, 0,
                     fails=fails, repairs=[attempt])
        runlog.append_run_log(
            tree, run_id, "repair", "repair-attempt",
            f"attempt {attempt['attempt']}: quarantined "
            f"{len(attempt['files'])} file(s)")

    ledger["fails"] = fails
    if fails:
        ledger["status"] = "needs-human"
        save_run(tree, run_id, ledger)
        update_index(tree)
        runlog.append_run_log(tree, run_id, "diagnose", "needs-human",
                              f"{len(fails)} fail(s) remain after "
                              f"{repairs_done} repair attempt(s)")
        print(f"run {run_id}: needs-human, {len(fails)} fail(s) remain "
              f"after {repairs_done} repair attempt(s)")
        for d in diagnosis:
            print(f"FAIL [{d['kind']}]: {d['fail']}")
        return 1

    # package stage: stage a clean deliverable, then stop for approval
    started = utcnow()
    staged = tree / ".pts" / "staged" / run_id
    product_version = (ROOT / "VERSION").read_text().strip() \
        if (ROOT / "VERSION").is_file() else "v0.0.0"
    if not product_version.startswith("v"):
        product_version = "v" + product_version
    r = subprocess.run([sys.executable, str(SCRIPTS / "package.py"),
                        "--tree", str(tree), "--out", str(staged),
                        "--version", product_version],
                       capture_output=True, text=True)
    print(r.stdout.strip())
    if r.returncode != 0:
        print(r.stderr.strip(), file=sys.stderr)
        record_stage(tree, run_id, ledger, "package", started,
                     r.returncode, fails=["package.py failed"])
        ledger["status"] = "needs-human"
        ledger["fails"] = ["package.py failed"]
        save_run(tree, run_id, ledger)
        update_index(tree)
        runlog.append_run_log(tree, run_id, "package", "package-failed",
                              "package.py failed")
        return 1
    record_stage(tree, run_id, ledger, "package", started, 0)
    runlog.append_run_log(tree, run_id, "package", "package-staged",
                          str(staged))
    ledger["staged"] = str(staged)
    ledger["status"] = "awaiting-approval"
    started = utcnow()
    record_stage(tree, run_id, ledger, "approval-stop", started, 0)
    save_run(tree, run_id, ledger)
    update_index(tree)
    runlog.append_run_log(tree, run_id, "approval-stop",
                          "awaiting-approval", f"staged: {staged}")
    print(f"run {run_id}: awaiting-approval")
    print(f"staged package: {staged}")
    print(f"pts verdict --tree {tree} --run {run_id} "
          f"--decision ship|fix|hold --note \"...\"")
    return 0


def cmd_runs(args):
    tree = Path(args.tree).expanduser().resolve()
    if not tree.is_dir():
        print(f"tree {tree} is not a directory", file=sys.stderr)
        return 2
    index = update_index(tree)
    if not index["runs"]:
        print(f"no runs recorded under {tree}/.pts/runs/")
        return 0
    for e in index["runs"]:
        print(f"{e['run_id']}  status={e['status']}  "
              f"stage={e['stage_reached']}  fails={e['fails']}")
    return 0


def cmd_verdict(args):
    tree = Path(args.tree).expanduser().resolve()
    ledger = load_run(tree, args.run)
    if ledger is None:
        print(f"no run {args.run} under {tree}/.pts/runs/",
              file=sys.stderr)
        return 2
    if ledger.get("status") != "awaiting-approval":
        print(f"refusing verdict: run {args.run} is "
              f"{ledger.get('status')}, not awaiting-approval",
              file=sys.stderr)
        return 2
    if ledger.get("verdict") is not None:
        print(f"refusing verdict: run {args.run} already has a verdict",
              file=sys.stderr)
        return 2
    ledger["verdict"] = {"decision": args.decision,
                         "note": args.note or "",
                         "recorded": utcnow()}
    ledger["status"] = f"verdict-{args.decision}"
    started = utcnow()
    record_stage(tree, args.run, ledger, "verdict", started, 0)
    save_run(tree, args.run, ledger)
    update_index(tree)
    runlog.append_run_log(tree, args.run, "verdict", "verdict-recorded",
                          f"{args.decision}"
                          + (f" — {args.note}" if args.note else ""))
    print(f"run {args.run}: verdict recorded: {args.decision}"
          + (f" — {args.note}" if args.note else ""))
    print("verdict records a human decision only; nothing was "
          "published, pushed, or shipped.")
    return 0


def main():
    ap = argparse.ArgumentParser(prog="pts")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("orchestrate")
    p.add_argument("--tree", required=True)
    p.add_argument("--brief", required=True)
    p.add_argument("--max-repairs", type=int, default=None)
    p = sub.add_parser("runs")
    p.add_argument("--tree", required=True)
    p = sub.add_parser("verdict")
    p.add_argument("--tree", required=True)
    p.add_argument("--run", required=True)
    p.add_argument("--decision", required=True,
                   choices=["ship", "fix", "hold"])
    p.add_argument("--note", default="")
    args = ap.parse_args()
    if args.cmd == "orchestrate":
        return cmd_orchestrate(args)
    if args.cmd == "runs":
        return cmd_runs(args)
    if args.cmd == "verdict":
        return cmd_verdict(args)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
