#!/usr/bin/env python3
"""Termux compatibility harness: proves the packaging is Termux-safe.

Usage: termux-check.py [--product DIR]

Checks (each printed PASS/FAIL, exit 0 only when all pass):
1. python3 >= 3.9 is present.
2. The installer invokes no privilege escalation: install.sh and
   uninstall.sh contain no sudo/su/doas, and nothing in them refuses
   to run as a non-root user.
3. The installer writes only under its PREFIX: no hardcoded absolute
   system path (/usr/local, /data/data/...) in install.sh or
   uninstall.sh, and the installer accepts a PREFIX argument (or
   PTS_PREFIX) so a Termux-style prefix works.
4. Simulated Termux prefix install: install into a temp directory
   laid out like /data/data/com.termux/files/usr (usr/bin, usr/share)
   with a scratch HOME, then run the installed `pts version`
   (must print the product version), `pts doctor` (exit 0), and
   `pts validate` (0 fails) from that prefix.
5. termux-api absence is handled gracefully: with no termux-api on
   PATH, `pts doctor` still exits 0 and reports it as optional.

Honest limit, stated in the output: this proves the packaging is
Termux-safe (no root, $PREFIX paths, graceful degradation). It does
NOT prove the product works on a real phone — that run is still the
user's verdict on their own device.
"""
import argparse
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


def run(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, **kw)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--product", default=None)
    args = ap.parse_args()
    root = Path(args.product).expanduser().resolve() if args.product \
        else Path(__file__).resolve().parents[1]
    results = []

    def check(name, ok, detail=""):
        results.append((name, ok))
        print(f"{'PASS' if ok else 'FAIL'}: {name} {detail}")

    # 1. python3 >= 3.9
    check("python3 >= 3.9", sys.version_info >= (3, 9),
          sys.version.split()[0])

    # 2. No privilege escalation in the installer.
    installer = (root / "install.sh").read_text(errors="ignore")
    uninstaller = (root / "uninstall.sh").read_text(errors="ignore")
    escalates = re.search(r"(?m)^\s*(sudo|su|doas)\b", installer + "\n" + uninstaller)
    check("installer invokes no privilege escalation (no sudo/su/doas)",
          escalates is None,
          f"found: {escalates.group(0).strip()}" if escalates else "")

    # 3. No hardcoded system paths; PREFIX is honoured.
    hardcoded = re.search(r"/usr/local|/data/data|/etc/|/opt/", installer + "\n" + uninstaller)
    honours_prefix = "PTS_PREFIX" in installer and re.search(r"\$1|\$\{1", installer) is not None
    check("installer writes only under its PREFIX (no hardcoded paths)",
          hardcoded is None and honours_prefix,
          "hardcoded path found" if hardcoded else "")

    # 4-5. Simulated Termux prefix install.
    version = (root / "VERSION").read_text().strip() \
        if (root / "VERSION").is_file() else "unknown"
    with tempfile.TemporaryDirectory(prefix="pts-termux-") as td:
        work = Path(td)
        sim_usr = work / "usr"          # stands in for .../files/usr
        sim_home = work / "home"
        sim_home.mkdir()
        env = dict(os.environ)
        env["HOME"] = str(sim_home)
        env["PATH"] = "/usr/bin:/bin"   # no termux-api, no extras
        r = run(["bash", str(root / "install.sh"), str(sim_usr)],
                env=env)
        installed = (sim_usr / "bin" / "pts").is_file()
        check("simulated Termux-prefix install succeeds",
              r.returncode == 0 and installed,
              f"exit={r.returncode} " + (r.stderr.strip().splitlines()[-1]
                                          if r.returncode else ""))
        if installed:
            pts = str(sim_usr / "bin" / "pts")
            r = run([pts, "version"], env=env)
            check("installed pts reports the product version",
                  r.returncode == 0 and r.stdout.strip() == version,
                  r.stdout.strip())
            r = run([pts, "doctor"], env=env)
            check("installed pts doctor exits 0 in the Termux-like prefix",
                  r.returncode == 0, f"exit={r.returncode}")
            check("termux-api absence is graceful (doctor calls it optional)",
                  "not present (optional)" in r.stdout,
                  "doctor did not report termux-api as optional")
            r = run([pts, "validate"], env=env)
            check("installed pts validate: 0 fails",
                  r.returncode == 0 and "FAIL: 0" in r.stdout,
                  r.stdout.strip().splitlines()[-1] if r.stdout else "")
    print("NOTE: this proves the packaging is Termux-safe. A real-phone "
          "run is still the user's verdict on their own device.")
    failed = [n for n, ok in results if not ok]
    print(f"RESULT: {len(results) - len(failed)}/{len(results)} passed, "
          f"FAIL: {len(failed)}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
