#!/usr/bin/env python3
"""Structured per-run logging for phone-to-ship. Stdlib only.

One JSON event per line in `.pts/runs/<run-id>/log.jsonl`:
    {"ts": "...", "stage": "test", "event": "check-failed",
     "detail": "missing required file: index.html"}

Commands that are not part of a run (snapshot, restore, config) write
to the tree-level `.pts/ops.jsonl` instead, same format, so there is
always an append-only record of what touched a tree.

Nothing here ever overwrites a log: events only append.
"""
import json
from datetime import datetime, timezone
from pathlib import Path


def utcnow():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _append(path, stage, event, detail):
    path.parent.mkdir(parents=True, exist_ok=True)
    record = {"ts": utcnow(), "stage": stage, "event": event,
              "detail": detail if detail is not None else ""}
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")
    return record


def append_run_log(tree, run_id, stage, event, detail=None):
    """Append one event to .pts/runs/<run-id>/log.jsonl."""
    return _append(Path(tree) / ".pts" / "runs" / run_id / "log.jsonl",
                   stage, event, detail)


def append_ops_log(tree, stage, event, detail=None):
    """Append one event to the tree-level .pts/ops.jsonl."""
    return _append(Path(tree) / ".pts" / "ops.jsonl", stage, event, detail)


def read_run_log(tree, run_id):
    """Return the list of events for a run, or None if there is no log."""
    path = Path(tree) / ".pts" / "runs" / run_id / "log.jsonl"
    if not path.is_file():
        return None
    events = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            events.append(json.loads(line))
        except ValueError:
            events.append({"ts": "", "stage": "", "event": "unparsable",
                           "detail": line[:200]})
    return events
