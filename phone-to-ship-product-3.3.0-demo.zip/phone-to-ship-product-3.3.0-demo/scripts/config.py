#!/usr/bin/env python3
"""pts config: project settings, stored consistently in .pts/config.json.

Usage:
  config.py --tree DIR                 print the current config (JSON)
  config.py --tree DIR get KEY         print one value
  config.py --tree DIR set KEY VALUE   set one value

Validated keys:
- name:        project name, 1-100 printable characters
- target:      web, apk, or web,apk (either order)
- max-repairs: integer 0-10 (default for `pts orchestrate` when
               --max-repairs is not given on the command line)
- version:     a version like 3.2.0 or v3.2.0

Unknown keys and invalid values are refused with exit 2 and a clear
error; nothing is written on a refusal. The config file is created
on first set. `pts orchestrate` reads max-repairs from it when
present; the brief is still authoritative for name and target.
"""
import argparse
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import runlog  # noqa: E402

KEYS = ("name", "target", "max-repairs", "version")
VERSION_RE = re.compile(r"^v?\d+\.\d+\.\d+$")


def config_path(tree):
    return Path(tree) / ".pts" / "config.json"


def load_config(tree):
    path = config_path(tree)
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text())
    except (ValueError, OSError) as e:
        print(f"config {path} is unreadable: {e}", file=sys.stderr)
        sys.exit(2)
    if not isinstance(data, dict):
        print(f"config {path} is not a JSON object", file=sys.stderr)
        sys.exit(2)
    return data


def save_config(tree, config):
    path = config_path(tree)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(config, indent=2, sort_keys=True) + "\n")


def validate(key, value):
    """Return an error string, or None when the value is valid."""
    if key == "name":
        if not value or len(value) > 100 or any(ord(c) < 32 for c in value):
            return "name must be 1-100 printable characters"
        return None
    if key == "target":
        parts = [p.strip() for p in value.split(",") if p.strip()]
        if not parts or any(p not in ("web", "apk") for p in parts) \
                or len(set(parts)) != len(parts):
            return "target must be web, apk, or web,apk"
        return None
    if key == "max-repairs":
        try:
            n = int(value)
        except ValueError:
            return "max-repairs must be an integer 0-10"
        if str(n) != str(value).strip() or not 0 <= n <= 10:
            return "max-repairs must be an integer 0-10"
        return None
    if key == "version":
        if not VERSION_RE.match(value.strip()):
            return "version must look like 3.2.0 or v3.2.0"
        return None
    return f"unknown key: {key} (valid keys: {', '.join(KEYS)})"


def normalize(key, value):
    if key == "max-repairs":
        return int(value)
    if key == "target":
        return ",".join(p.strip() for p in value.split(",") if p.strip())
    if key == "version":
        return value.strip()
    return value


def main():
    ap = argparse.ArgumentParser(prog="pts config")
    ap.add_argument("--tree", required=True)
    sub = ap.add_subparsers(dest="cmd", required=False)
    p = sub.add_parser("get")
    p.add_argument("key")
    p = sub.add_parser("set")
    p.add_argument("key")
    p.add_argument("value")
    args = ap.parse_args()
    tree = Path(args.tree).expanduser().resolve()
    if not tree.is_dir():
        print(f"tree {tree} is not a directory", file=sys.stderr)
        return 2
    config = load_config(tree)
    if args.cmd is None:
        print(json.dumps(config, indent=2, sort_keys=True))
        return 0
    if args.key not in KEYS:
        print(f"unknown key: {args.key} "
              f"(valid keys: {', '.join(KEYS)})", file=sys.stderr)
        return 2
    if args.cmd == "get":
        if args.key not in config:
            print(f"config key {args.key} is not set", file=sys.stderr)
            return 2
        print(config[args.key])
        return 0
    if args.cmd == "set":
        err = validate(args.key, args.value)
        if err:
            print(f"refusing config set: {err}", file=sys.stderr)
            return 2
        config[args.key] = normalize(args.key, args.value)
        save_config(tree, config)
        runlog.append_ops_log(tree, "config", "config-set",
                              f"{args.key}={config[args.key]}")
        print(f"config: {args.key} = {config[args.key]}")
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
