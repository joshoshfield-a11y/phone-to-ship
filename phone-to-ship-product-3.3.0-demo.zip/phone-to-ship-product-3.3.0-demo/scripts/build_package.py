#!/usr/bin/env python3
"""Build the packaged phone-to-ship product: a self-contained zip + manifest.
Usage: build_package.py --version 3.3.0 [--out ~/workspace/your_files/phone-to-ship-product-3.3.0.zip]
Gates, in order — a failure at any gate aborts the build with exit 1
and no zip is written:
1. validate_templates.py (0 fails).
2. py_compile every script in scripts/ (syntax must be clean).
3. The full automated suite: tests/run_tests.py --product <root>
   --pts <root>/bin/pts (this is the gate 3.0.0's build only
   pretended to run — it invoked `unittest discover`, which matches
   no test file here; the real suite runs now). The suite runs with
   PTS_SELF_TEST_DEPTH incremented, so a nested suite skips the
   install-touching tests (see run_tests.py) — the build gate
   therefore runs the depth-1 suite (26 checks); the full 30-check
   suite runs via `pts self-test` and scripts/ci-check.sh.
Then stage a clean copy of the whole product tree (SKILL.md,
skill.yaml, README.md, CHANGELOG.md, LICENSE-TERMS-TEMPLATE.md,
INSTALL.md, VERSION, install.sh, uninstall.sh, bin/, references/,
scripts/, assets/, docs/, tests/, fixtures/, .github/) under a temp
dir on home disk (never /tmp), excluding __pycache__, *.pyc, dist/,
and .git. Write PACKAGE-MANIFEST.json into the package (entries cover
every staged file except the manifest itself — a manifest cannot list
its own hash), zip it sorted, report bytes + sha256, and copy the
fresh manifest back into the product tree root so a source-tree
install stays uninstallable (uninstall.sh verifies the marker).
The zip refuses to overwrite an existing file (exit 2).
Nothing in the package contains a real key, address, username, or
device ID; templates carry YOUR_ placeholders only
(validate_templates.py proves it).
"""
import argparse, hashlib, json, os, shutil, subprocess, sys, tempfile, zipfile
from pathlib import Path


def sha(p):
    h = hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda: f.read(65536), b""):
            h.update(b)
    return h.hexdigest()


def gate(cmd, label):
    r = subprocess.run(cmd, capture_output=True, text=True)
    print(r.stdout, end="")
    if r.stdout and not r.stdout.endswith("\n"):
        print()
    if r.returncode != 0:
        print(f"build aborted: {label}", file=sys.stderr)
        if r.stderr:
            print(r.stderr, file=sys.stderr)
        return False
    return True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--version", default="3.3.0")
    ap.add_argument("--out", default=None)
    ap.add_argument("--source", default=None,
                    help="product tree to build (default: the tree "
                    "containing this script)")
    args = ap.parse_args()
    if not args.version or any(c in args.version for c in "/\\\0"):
        ap.error("invalid version")
    skill = Path(args.source).expanduser().resolve() if args.source \
        else Path(__file__).resolve().parents[1]
    # Gate 1: template validation.
    if not gate([sys.executable,
                 str(skill / "scripts" / "validate_templates.py"),
                 "--skill", str(skill)], "template validation failed"):
        return 1
    # Gate 2: every script compiles (recursive: a flat scripts/*.py
    # glob would silently skip sub-packages). Bytecode goes to a temp
    # file (py_compile refuses /dev/null as a target), which is
    # deleted after, so the source tree stays free of __pycache__.
    import tempfile
    _fd, _cfile = tempfile.mkstemp(prefix="pts-pycompile-")
    os.close(_fd)
    try:
        for py in sorted((skill / "scripts").rglob("*.py")):
            if not gate([sys.executable, "-c",
                         "import py_compile, sys; "
                         "py_compile.compile(sys.argv[1], "
                         "cfile=sys.argv[2], doraise=True)",
                         str(py), _cfile],
                        f"{py.name} does not compile"):
                return 1
    finally:
        os.unlink(_cfile)
    # Gate 3: the full automated suite (the real one, not unittest
    # discover — run_tests.py is a script, not a unittest module).
    # PTS_SELF_TEST_DEPTH is incremented so a nested suite run skips
    # the install-touching tests (termux-check, upgrade, build gate) —
    # the suite's own build-gate test invokes this builder, and without
    # the depth guard that would recurse. Consequence, stated plainly:
    # the build gate runs the depth-1 suite (34 checks); the full
    # 38-check suite runs via `pts self-test` and scripts/ci-check.sh.
    suite_env = dict(os.environ)
    suite_env["PTS_SELF_TEST_DEPTH"] = str(
        int(os.environ.get("PTS_SELF_TEST_DEPTH", "0")) + 1)
    r = subprocess.run(
        [sys.executable, str(skill / "tests" / "run_tests.py"),
         "--product", str(skill),
         "--pts", str(skill / "bin" / "pts")],
        capture_output=True, text=True, env=suite_env)
    print(r.stdout, end="")
    if r.stdout and not r.stdout.endswith("\n"):
        print()
    if r.returncode != 0:
        print("build aborted: automated test suite failed", file=sys.stderr)
        if r.stderr:
            print(r.stderr, file=sys.stderr)
        return 1
    out = Path(args.out).expanduser().resolve() if args.out \
        else Path.home() / f"phone-to-ship-product-{args.version}.zip"
    if out.exists():
        print(f"refusing to overwrite existing file: {out}",
              file=sys.stderr)
        return 2
    out.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="phone-to-ship-") as tmp:
        stage = Path(tmp) / f"phone-to-ship-product-{args.version}"
        shutil.copytree(
            skill, stage,
            ignore=shutil.ignore_patterns(
                "__pycache__", "*.pyc", "dist", ".git",
                "phone-to-ship-product-*.zip"))
        # Manifest: every staged file except the manifest itself.
        entries = []
        for p in sorted(stage.rglob("*")):
            if p.is_file() and p.name != "PACKAGE-MANIFEST.json":
                entries.append({"path": p.relative_to(stage).as_posix(),
                                "bytes": p.stat().st_size,
                                "sha256": sha(p)})
        manifest = {"skill": "phone-to-ship", "version": args.version,
                    "files": len(entries),
                    "bytes": sum(e["bytes"] for e in entries),
                    "entries": entries}
        manifest_text = json.dumps(manifest, indent=2) + "\n"
        (stage / "PACKAGE-MANIFEST.json").write_text(manifest_text)
        with zipfile.ZipFile(out, "x", zipfile.ZIP_DEFLATED,
                             compresslevel=9) as z:
            for p in sorted(stage.rglob("*")):
                if p.is_file():
                    z.write(p, arcname=f"{stage.name}/"
                            f"{p.relative_to(stage).as_posix()}")
    # Keep the product tree's own manifest fresh: a source-tree
    # install must stay uninstallable (uninstall.sh checks the marker).
    (skill / "PACKAGE-MANIFEST.json").write_text(manifest_text)
    print(f"created {out}\nbytes: {out.stat().st_size}\n"
          f"sha256: {sha(out)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
