#!/usr/bin/env python3
"""Phone-to-ship readiness gate on a built tree. Exit 0 = pass, 1 = fail.
Usage: ship-check.py --tree <built-dir> [--require index.html]
  [--skip-secret-scan]
FAILs: missing required entry file, JS syntax error, excluded input
(*.py, raw/, phases/, snapshots/, node_modules/, __pycache__/) present
in the package tree, symlink in the tree, credential-shaped value
(private-key marker, GitHub/Stripe/AWS token patterns, credential
assignment) in a file under 5 MB, empty tree.
WARNINGs: no README.md, node unavailable (JS checks skipped).
Prints counts, bytes, and hashes — never a bare 'tests pass'.
The report is JSON (tree, files, bytes, sha256_index, fails,
warnings) so orchestrate.py can parse it.
`.pts/` is orchestration bookkeeping (run ledgers, quarantine,
staged packages), not package content: it is skipped entirely, so a
quarantined `.py` file is not re-flagged.
Does NOT prove APK signature, Vercel READY, or real-phone feel; those
are separate gates, reported separately. The secret scan is a
pattern match, not a security audit: it reports the pattern label
and path, never the matched value.
"""
import argparse, hashlib, json, re, subprocess, sys
from pathlib import Path

EXCLUDED_DIRS = {".git", "node_modules", "raw", "phases", "snapshots",
                 "__pycache__", "tests", ".pts"}
EXCLUDED_SUFFIXES = {".py", ".pyc", ".pyo"}
SECRET_PATTERNS = [
    (r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----",
     "private key marker"),
    (r"\bgh[pousr]_[A-Za-z0-9]{20,}\b", "GitHub token-like value"),
    (r"\bsk_live_[A-Za-z0-9]{12,}\b", "Stripe live secret-like value"),
    (r"(?i)\bAKIA[0-9A-Z]{16}\b", "AWS access-key-like value"),
    (r"(?i)(?:api[_-]?key|access[_-]?token|client[_-]?secret)"
     r"\s*[:=]\s*[\"'][^\"']{12,}[\"']", "credential assignment"),
]
SECRET_SCAN_MAX_BYTES = 5_000_000


def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tree", required=True)
    ap.add_argument("--require", action="append", default=[])
    ap.add_argument("--skip-secret-scan", action="store_true")
    args = ap.parse_args()
    tree = Path(args.tree).expanduser().resolve()
    fails, warns = [], []
    if not tree.is_dir():
        print(f"FAIL: tree {tree} is not a directory")
        return 1
    files = []
    for p in tree.rglob("*"):
        if p.is_symlink():
            fails.append(f"symlink in deliverable tree: "
                         f"{p.relative_to(tree)}")
            continue
        if not p.is_file():
            continue
        rel = p.relative_to(tree)
        # .pts/ is orchestration bookkeeping: skip it entirely.
        if ".pts" in rel.parts:
            continue
        if any(part in EXCLUDED_DIRS for part in rel.parts):
            fails.append(f"excluded input in package tree: {rel}")
            continue
        if p.suffix in EXCLUDED_SUFFIXES:
            fails.append(f"excluded input in package tree: {rel}")
            continue
        files.append(p)
    if not files:
        fails.append("empty tree: no files")
    for req in (args.require or ["index.html"]):
        q = Path(req)
        if q.is_absolute() or ".." in q.parts:
            fails.append(f"invalid required path: {req}")
        elif not (tree / q).is_file():
            fails.append(f"missing required file: {req}")
    for p in files:
        rel = p.relative_to(tree)
        if p.suffix == ".js":
            try:
                r = subprocess.run(["node", "--check", str(p)],
                                   capture_output=True, text=True, timeout=20)
            except FileNotFoundError:
                warns.append("Node.js unavailable; JavaScript syntax "
                             "checks skipped")
                break
            except subprocess.TimeoutExpired:
                fails.append(f"JS syntax check timed out: {rel}")
                continue
            if r.returncode != 0:
                fails.append(f"syntax: {rel}: {r.stderr.strip()[:240]}")
        if not args.skip_secret_scan \
                and p.stat().st_size <= SECRET_SCAN_MAX_BYTES:
            try:
                content = p.read_text(errors="ignore")
            except OSError:
                warns.append(f"could not read for secret scan: {rel}")
                continue
            for pattern, label in SECRET_PATTERNS:
                if re.search(pattern, content):
                    fails.append(f"{label} pattern in {rel}")
    if not (tree / "README.md").is_file():
        warns.append("no README.md in package tree")
    total = sum(p.stat().st_size for p in files)
    report = {"tree": str(tree), "files": len(files), "bytes": total,
              "sha256_index": sha256(tree / "index.html")
              if (tree / "index.html").is_file() else None,
              "fails": fails, "warnings": sorted(set(warns))}
    print(json.dumps(report, indent=2))
    print(f"FAIL: {len(fails)}  WARN: {len(set(warns))}")
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(main())
