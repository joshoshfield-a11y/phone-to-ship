#!/usr/bin/env python3
"""pts snapshot / restore: restore known-good project states.

Usage:
  snapshot.py --tree DIR snapshot            record the tree now
  snapshot.py --tree DIR restore --id ID     restore snapshot ID
  snapshot.py --tree DIR list                list snapshots

A snapshot records every file in the tree except `.pts/` itself
(orchestration bookkeeping is never part of a project state):
`.pts/snapshots/<id>/` holds a copy of each file plus
`snapshot.json`, a manifest of path, bytes, and sha256 per file.

Restore refuses a corrupt snapshot: every file in the snapshot is
hash-checked against the manifest BEFORE anything is copied back,
and a mismatch refuses the restore (exit 2) with the bad path named.
After copying, every restored file is hash-checked again and the
result is reported. Files created after the snapshot are left in
place and listed as "not in snapshot"; restore never deletes.
"""
import argparse
import hashlib
import json
import secrets
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import runlog  # noqa: E402


def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def snapshots_dir(tree):
    return Path(tree) / ".pts" / "snapshots"


def tree_files(tree):
    """All files in the tree except .pts/ bookkeeping."""
    out = []
    for p in sorted(Path(tree).rglob("*")):
        if not p.is_file():
            continue
        if ".pts" in p.relative_to(tree).parts:
            continue
        out.append(p)
    return out


def new_snapshot_id():
    return (datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
            + "-" + secrets.token_hex(2))


def cmd_snapshot(tree):
    files = tree_files(tree)
    if not files:
        print(f"refusing snapshot: {tree} has no files outside .pts/",
              file=sys.stderr)
        return 2
    snap_id = new_snapshot_id()
    dest = snapshots_dir(tree) / snap_id
    dest.mkdir(parents=True, exist_ok=True)
    entries = []
    for src in files:
        rel = src.relative_to(tree)
        target = dest / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, target)
        entries.append({"path": rel.as_posix(), "bytes": src.stat().st_size,
                        "sha256": sha256(src)})
    manifest = {"id": snap_id, "tree": str(tree),
                "created": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                "files": len(entries),
                "bytes": sum(e["bytes"] for e in entries),
                "entries": entries}
    (dest / "snapshot.json").write_text(json.dumps(manifest, indent=2))
    runlog.append_ops_log(tree, "snapshot", "snapshot-taken",
                          f"{snap_id}: {len(entries)} files")
    print(f"snapshot {snap_id}: {len(entries)} files, "
          f"{manifest['bytes']} bytes -> .pts/snapshots/{snap_id}/")
    return 0


def load_manifest(tree, snap_id):
    path = snapshots_dir(tree) / snap_id / "snapshot.json"
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text())
    except (ValueError, OSError):
        return None


def cmd_restore(tree, snap_id):
    snap = snapshots_dir(tree) / snap_id
    if not snap.is_dir():
        print(f"no snapshot {snap_id} under {tree}/.pts/snapshots/",
              file=sys.stderr)
        return 2
    manifest = load_manifest(tree, snap_id)
    if manifest is None:
        print(f"refusing restore: snapshot {snap_id} has no readable "
              f"manifest (corrupt snapshot)", file=sys.stderr)
        return 2
    # Verify the snapshot BEFORE copying anything back.
    corrupt = []
    for e in manifest["entries"]:
        f = snap / e["path"]
        if not f.is_file() or f.stat().st_size != e["bytes"] \
                or sha256(f) != e["sha256"]:
            corrupt.append(e["path"])
    if corrupt:
        print(f"refusing restore: snapshot {snap_id} is corrupt, "
              f"{len(corrupt)} file(s) do not match the manifest:",
              file=sys.stderr)
        for path in corrupt:
            print(f"  corrupt: {path}", file=sys.stderr)
        runlog.append_ops_log(tree, "restore", "restore-refused-corrupt",
                              f"{snap_id}: {len(corrupt)} file(s)")
        return 2
    restored = []
    for e in manifest["entries"]:
        src = snap / e["path"]
        dest = Path(tree) / e["path"]
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dest)
        restored.append(e["path"])
    # Verify hashes after restore.
    bad = [p for p in restored
           if sha256(Path(tree) / p) != next(
               e["sha256"] for e in manifest["entries"] if e["path"] == p)]
    if bad:
        print(f"restore failed verification after copy: {bad}",
              file=sys.stderr)
        return 1
    current = {p.relative_to(tree).as_posix() for p in tree_files(tree)}
    extra = sorted(current - set(restored))
    runlog.append_ops_log(tree, "restore", "restore-done",
                          f"{snap_id}: {len(restored)} files")
    print(f"restored snapshot {snap_id}: {len(restored)} files, "
          f"hashes verified after restore")
    if extra:
        print(f"not in snapshot, left in place ({len(extra)}):")
        for path in extra:
            print(f"  left: {path}")
    return 0


def cmd_list(tree):
    base = snapshots_dir(tree)
    if not base.is_dir():
        print(f"no snapshots under {tree}/.pts/snapshots/")
        return 0
    found = []
    for manifest_path in sorted(base.glob("*/snapshot.json")):
        try:
            manifest = json.loads(manifest_path.read_text())
        except (ValueError, OSError):
            continue
        found.append(manifest)
    if not found:
        print(f"no snapshots under {tree}/.pts/snapshots/")
        return 0
    for m in found:
        print(f"{m.get('id')}  files={m.get('files')}  "
              f"bytes={m.get('bytes')}  created={m.get('created')}")
    return 0


def main():
    ap = argparse.ArgumentParser(prog="pts snapshot")
    ap.add_argument("--tree", required=True)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("snapshot")
    p = sub.add_parser("restore")
    p.add_argument("--id", required=True)
    sub.add_parser("list")
    args = ap.parse_args()
    tree = Path(args.tree).expanduser().resolve()
    if not tree.is_dir():
        print(f"tree {tree} is not a directory", file=sys.stderr)
        return 2
    if args.cmd == "snapshot":
        return cmd_snapshot(tree)
    if args.cmd == "restore":
        return cmd_restore(tree, args.id)
    if args.cmd == "list":
        return cmd_list(tree)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
