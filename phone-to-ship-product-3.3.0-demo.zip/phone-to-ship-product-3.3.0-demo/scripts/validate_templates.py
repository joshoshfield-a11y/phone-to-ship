#!/usr/bin/env python3
"""Validate every template in assets/templates/. Exit 0 = pass, 1 = fail.
Usage: validate_templates.py [--skill <skill-dir>]
Checks:
- No real secret material: no 'BEGIN PRIVATE KEY', no baked phone username
  (u0_a...), no tailnet IP, no id_phone path, no password/token literal.
- Shell templates pass `bash -n` and refuse to run with placeholders intact
  (their guard strings are present, not just hoped for).
- vercel.json parses as JSON.
- Every template is actually consumed: scaffold.py maps it, or it is a
  documented standalone (gitignore.txt -> .gitignore, vercel.json -> vercel.json).
Prints counts, not a bare 'pass'.
"""
import json, re, subprocess, sys
from pathlib import Path

SECRET_PATTERNS = [r"BEGIN (?:RSA )?PRIVATE KEY", r"u0_a\d+", r"100\.64\.\d+\.\d+",
                   r"id_phone", r"password\s*=\s*['\"][^'\"]+['\"]", r"ghp_[A-Za-z0-9]+"]

def main():
    skill = Path(sys.argv[sys.argv.index("--skill") + 1]).expanduser() if "--skill" in sys.argv else Path(__file__).resolve().parents[1]
    tmpl_dir = skill / "assets" / "templates"
    scaffold = (skill / "scripts" / "scaffold.py").read_text()
    fails, checked = [], 0
    for f in sorted(tmpl_dir.iterdir()):
        if not f.is_file(): continue
        checked += 1
        text = f.read_text(errors="ignore")
        for pat in SECRET_PATTERNS:
            if re.search(pat, text): fails.append(f"secret-pattern {pat} in {f.name}")
        if f.suffix == ".sh":
            r = subprocess.run(["bash", "-n", str(f)], capture_output=True, text=True)
            if r.returncode != 0: fails.append(f"bash -n failed: {f.name}: {r.stderr.strip()[:200]}")
            if "YOUR_" not in text or "Stop:" not in text: fails.append(f"shell template {f.name} missing placeholder guard")
        if f.name == "vercel.json":
            try: json.loads(text)
            except Exception as e: fails.append(f"vercel.json invalid JSON: {e}")
        if f.name not in scaffold and f.name not in ("gitignore.txt", "vercel.json"):
            fails.append(f"template {f.name} not consumed by scaffold.py")
    print(f"templates checked: {checked}")
    print(f"FAIL: {len(fails)}")
    for x in fails: print("  -", x)
    return 1 if fails else 0

if __name__ == "__main__":
    raise SystemExit(main())
