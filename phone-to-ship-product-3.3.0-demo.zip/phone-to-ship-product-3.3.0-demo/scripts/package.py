#!/usr/bin/env python3
"""Stage a clean web deliverable from a built tree. No network.
Usage: package.py --tree <built-dir> --out <package-dir> [--version v0.1.0]
Copies the tree excluding *.py/.pyc/.pyo, raw/, phases/, snapshots/,
node_modules/, __pycache__/, tests/, .git, and .pts/ (orchestration
bookkeeping: run ledgers, quarantine, staged packages are never
shipped inside the package).
Writes MANIFEST.json (product, version, files, bytes, index_sha256,
sha256 per file) and PHONE-CHECKLIST.md (verify the manifest hashes
after transfer, then play it on the phone and record the verdict).
Refuses a non-empty out dir (exit 2), refuses symlinks in the tree
(exit 2), and refuses a destination that contains, or is contained
by, the source tree (exit 2) — except a destination under the
source tree's own `.pts/` directory, which is where `pts orchestrate`
stages its packages. The package is a deliverable, not a claim: APK
signature, Vercel READY, and the real-phone verdict are still
separate gates.
"""
import argparse, hashlib, json, shutil, sys
from pathlib import Path

EXCLUDED_DIRS = {".git", "node_modules", "raw", "phases", "snapshots",
                 "__pycache__", "tests", ".pts"}
EXCLUDED_SUFFIXES = {".py", ".pyc", ".pyo"}


def sha(p):
    h = hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda: f.read(65536), b""):
            h.update(b)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--tree", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--version", default="v0.1.0")
    a = ap.parse_args()
    src = Path(a.tree).expanduser().resolve()
    out = Path(a.out).expanduser().resolve()
    if not src.is_dir():
        print("source tree does not exist", file=sys.stderr)
        return 2
    # A destination inside the source's own .pts/ is the orchestration
    # staging area (pts orchestrate stages there); every other
    # source/destination overlap is refused.
    under_pts = out == src / ".pts" or (src / ".pts") in out.parents
    if (src == out or src in out.parents or out in src.parents) \
            and not under_pts:
        print("source and destination must not contain one another",
              file=sys.stderr)
        return 2
    if out.exists() and (not out.is_dir() or any(out.iterdir())):
        print("refusing to overwrite non-empty destination",
              file=sys.stderr)
        return 2
    if not a.version or any(c in a.version for c in "/\\\0"):
        print("invalid version", file=sys.stderr)
        return 2
    files = []
    for p in sorted(src.rglob("*")):
        if p.is_symlink():
            print(f"refusing symlink: {p.relative_to(src)}",
                  file=sys.stderr)
            return 2
        if not p.is_file():
            continue
        rel = p.relative_to(src)
        if any(part in EXCLUDED_DIRS for part in rel.parts) \
                or p.suffix in EXCLUDED_SUFFIXES:
            continue
        files.append((p, rel))
    out.mkdir(parents=True, exist_ok=True)
    entries = []
    for p, rel in files:
        dest = out / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(p, dest)
        entries.append({"path": rel.as_posix(), "bytes": dest.stat().st_size,
                        "sha256": sha(dest)})
    total = sum(x["bytes"] for x in entries)
    index_hash = next((e["sha256"] for e in entries
                       if e["path"] == "index.html"), None)
    manifest = {"product": "Phone-to-Ship web deliverable",
                "version": a.version, "files": len(entries),
                "bytes": total, "index_sha256": index_hash,
                "entries": entries}
    (out / "MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")
    (out / "PHONE-CHECKLIST.md").write_text(
        f"# Phone verification — {a.version}\n\n"
        f"- Files: {len(entries)}\n- Bytes: {total}\n"
        f"- index.html sha256: {index_hash}\n\n"
        "Verify SHA-256 values in MANIFEST.json after transfer.\n"
        "Install/open on the target phone and test the primary workflow.\n"
        "Record device, OS, build, test date, defects and verdict.\n"
        "A build nobody played on a real phone is built, not shipped.\n")
    print(f"packaged {a.version}: {len(entries)} files, {total} bytes "
          f"at {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
