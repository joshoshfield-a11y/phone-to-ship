#!/usr/bin/env python3
"""Scaffold a phone-to-ship project. No network, no secrets.
Usage: scaffold.py --name my-game --out ~/workspace/my-game [--target web] [--target apk]
Creates: every working template from assets/templates/ (brief, checklist,
verdict, decision log, release notes, store listing, GitHub/Vercel checklist,
vercel.json, gitignore, skill playbook, manual phone steps + phone push script),
plus snapshots/, phases/, tests/, docs/, TEST-PLAN.md, SECURITY.md,
CHANGELOG.md, README.md.
Templates keep their YOUR_ placeholders until the user fills them in — the
shell templates refuse to run while placeholders remain, and
validate_templates.py proves no real secret shipped in a template.
Refuses a non-empty out dir (exit 2) — never scaffold over live work.
The project name must be 1-100 printable characters.
"""
import argparse, sys
from pathlib import Path

GITIGNORE_FALLBACK = """# phone-to-ship: never commit secrets or signing keys
*.keystore
*.jks
.keypass
.env
*.pem
*.key
secrets/
snapshots/
"""

TEST_PLAN = """# Test plan

## Acceptance criteria
- [ ] Primary user journey works on each target.
- [ ] Error and empty states are handled.
- [ ] Mobile layout and touch controls are checked.
- [ ] Release artifact contents and checksum are verified.

## Evidence
Record commands, environment, results, and skipped checks.
"""

SECURITY_NOTES = """# Security notes

- [ ] No secrets committed or packaged.
- [ ] Permissions and data collection are documented.
- [ ] Dependencies and licenses are reviewed.
- [ ] Release artifact is inspected.
"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--target", action="append", default=None)
    args = ap.parse_args()
    name = args.name.strip()
    if not name or len(name) > 100 or any(ord(c) < 32 for c in name):
        ap.error("name must be 1-100 printable characters")
    if not args.target:
        args.target = ["web"]
    out = Path(args.out).expanduser()
    if out.exists() and any(out.iterdir()):
        print(f"refusing: {out} is not empty", file=sys.stderr)
        return 2
    skill = Path(__file__).resolve().parents[1]
    out.mkdir(parents=True, exist_ok=True)
    for d in ("snapshots", "phases", "tests", "docs"):
        (out / d).mkdir(exist_ok=True)
    mapping = (("project-brief.md", "BRIEF.md"),
               ("shipping-checklist.md", "SHIPPING-CHECKLIST.md"),
               ("phone-verdict.md", "PHONE-VERDICT.md"),
               ("decision-log.md", "DECISION-LOG.md"),
               ("release-notes.md", "RELEASE-NOTES.md"),
               ("store-listing.md", "STORE-LISTING.md"),
               ("github-vercel-checklist.md", "GITHUB-VERCEL-CHECKLIST.md"),
               ("skill-playbook.md", "SKILL-PLAYBOOK.md"),
               ("termux-manual-steps.md", "TERMUX-MANUAL-STEPS.md"),
               ("phone-push-template.sh", "phone-push.sh"))
    for tmpl, dest in mapping:
        src = skill / "assets" / "templates" / tmpl
        text = src.read_text().replace("YOUR_PROJECT_NAME", name) \
            if src.exists() else f"# {tmpl}\n"
        (out / dest).write_text(text)
    # vercel.json and .gitignore are copied verbatim (their placeholders are
    # YOUR_BUILD_COMMAND / YOUR_OUTPUT_FOLDER, not a project name).
    vercel_src = skill / "assets" / "templates" / "vercel.json"
    (out / "vercel.json").write_text(
        vercel_src.read_text() if vercel_src.exists() else "{}\n")
    gitignore_src = skill / "assets" / "templates" / "gitignore.txt"
    (out / ".gitignore").write_text(
        gitignore_src.read_text() if gitignore_src.exists()
        else GITIGNORE_FALLBACK)
    (out / "TEST-PLAN.md").write_text(TEST_PLAN)
    (out / "SECURITY.md").write_text(SECURITY_NOTES)
    (out / "CHANGELOG.md").write_text(
        f"# {name}\n\n## v0.1.0 — scaffold\n"
        f"- Phone-to-ship project scaffolded. Targets: "
        f"{', '.join(args.target)}. Nothing built, shipped, or published "
        f"yet.\n")
    (out / "README.md").write_text(
        f"# {name}\n\nPhone-to-ship project. Targets: "
        f"{', '.join(args.target)}.\n\n"
        "Loop: brief -> build -> headless test -> your word -> ship -> "
        "real-phone verdict -> fix and re-ship.\n\n"
        "Nothing is merged, pushed, published, sent, or bought without "
        "your word. Snapshots go in snapshots/ (gitignored). A build "
        "nobody played on a real phone is built, not shipped.\n")
    print(f"scaffolded {name} -> {out} (targets: {', '.join(args.target)})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
