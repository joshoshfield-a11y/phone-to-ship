#!/usr/bin/env python3
"""pts doctor: environment report with missing-tool detection.

Usage: doctor.py [--root DIR]
Checks, in order:
- python3: required, >= 3.9. Anything older fails the check.
- bash: required (install.sh, uninstall.sh, and the shell templates).
- node: optional. Missing node only warns: JS syntax checks in
  `pts check` are skipped with a warning.
- git: optional. Needed only if the user wants version control.
- Termux: detected when $PREFIX names com.termux, `termux-info` is
  on PATH, or /data/data/com.termux exists. Detection is reported,
  never assumed.
- termux-api: optional. Its absence is reported as "not present
  (optional)", never a failure: nothing in this product requires it.

Exit 0 when every required tool is present, exit 1 otherwise, with
an install hint printed for each missing tool. Nothing here prints a
secret or a path that could be one.
"""
import os
import shutil
import sys
from pathlib import Path


REQUIRED_PYTHON = (3, 9)


def is_termux():
    prefix = os.environ.get("PREFIX", "")
    if "com.termux" in prefix:
        return True
    if shutil.which("termux-info"):
        return True
    return Path("/data/data/com.termux").exists()


def main():
    missing = []
    print("Phone-to-Ship environment report")
    print(f"Python: {sys.version.split()[0]}")
    if sys.version_info < REQUIRED_PYTHON:
        print(f"MISSING: python3 >= 3.9 is required "
              f"(found {sys.version.split()[0]}); install a newer Python")
        missing.append("python3")
    else:
        print("OK: python3 >= 3.9")
    bash = shutil.which("bash")
    print(f"Bash: {bash or 'not installed'}")
    if not bash:
        print("MISSING: bash is required (install.sh, uninstall.sh, "
              "shell templates); install bash")
        missing.append("bash")
    else:
        print("OK: bash")
    node = shutil.which("node")
    print(f"Node.js: {node or 'not installed (JS checks will be skipped)'}")
    if node:
        print("OK: node")
    else:
        print("NOTE: node is optional; JS syntax checks are skipped "
              "with a warning when it is absent")
    git = shutil.which("git")
    print(f"Git: {git or 'not installed (optional)'}")
    print(f"Platform: {sys.platform}")
    print(f"Termux environment: {'detected' if is_termux() else 'not detected'}")
    termux_api = shutil.which("termux-api")
    print(f"termux-api: {termux_api or 'not present (optional)'}")
    if not termux_api:
        print("NOTE: termux-api is optional; nothing in this product "
              "requires it, and its absence is handled gracefully")
    if missing:
        print(f"doctor: FAIL: {len(missing)} required tool(s) missing: "
              f"{', '.join(missing)}")
        return 1
    print("doctor: OK: all required tools present")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
