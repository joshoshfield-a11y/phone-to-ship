# Compatibility and support policy

This package is a workflow and a set of Python/Bash utilities. Actual project compatibility depends on the chosen engine, SDK, device ABI, OS version, account and host service. Verify versions at project start and record them in the project brief.

| Layer | Baseline | Notes |
|---|---|---|
| Python utilities | Python 3.9+ | Standard library only |
| Shell templates | Bash 4+ recommended | Review commands before execution |
| JS syntax checks | Node.js LTS | Optional; absence is reported as a warning |
| Android | Termux or remote Linux/desktop build host | Native Android build support varies by toolchain and device. `scripts/termux-check.py` proves the packaging is Termux-safe (no root, $PREFIX paths, graceful termux-api absence, simulated Termux-prefix install); it does NOT prove real-phone behavior — that run is still the user's verdict on their own device. |
| Web | Any documented modern web toolchain | Lockfile and browser testing required |
| Game engines | Project-pinned version | Do not assume latest engine compatibility |

A platform should be advertised as supported only after a clean install, repeatable build and representative device test. Maintain a versioned compatibility matrix based on actual test evidence.

## Termux harness (3.1.0)

`python3 scripts/termux-check.py` checks: python3 >= 3.9, no privilege escalation in the installer, no hardcoded paths outside $PREFIX, a simulated Termux-prefix install (temp directory laid out like `/data/data/com.termux/files/usr`) with the installed `pts version` / `pts doctor` / `pts validate` run from that prefix, and graceful handling when `termux-api` is absent. All checks must pass. The harness runs as part of `scripts/ci-check.sh` and `.github/workflows/ci.yml`.
