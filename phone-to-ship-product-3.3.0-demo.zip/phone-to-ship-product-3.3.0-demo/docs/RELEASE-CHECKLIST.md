# Product release checklist

- [ ] Remove private names, account details, local paths, device IDs, tokens and project-specific incident history.
- [ ] Confirm rights to every file and replace the license template with reviewed terms.
- [ ] Validate docs against actual script behavior and current platform requirements.
- [ ] Run template validation, unit tests, Python compilation and package build.
- [ ] Run the CI gate: `bash scripts/ci-check.sh` (validate, full suite, Termux harness, clean install + installed-binary orchestrate on both fixtures, uninstall). `scripts/build_package.py` refuses to build when the suite fails — do not bypass it.
- [ ] Verify the zip: `unzip -t`, zero `__pycache__` entries in `unzip -l`, manifest file count and hashes match the tree.
- [ ] Test install and scaffold on a clean environment.
- [ ] Test at least one real Android workflow and one alternate workspace if those are advertised.
- [ ] Verify archive listing, manifest, file sizes and SHA-256.
- [ ] Scan archive for secrets, personal information, malware and unwanted generated files.
- [ ] Prepare screenshots, demo project, product description, support policy and changelog.
- [ ] State tested versions, known limitations and what is not included.
- [ ] Obtain approval before listing, pricing or publishing.
