# First 30 minutes

1. Install a supported AI skill in the target environment using that product's current instructions.
2. Open `SKILL.md` and provide a project idea. Ask the assistant to draft a brief before writing code.
3. Choose where builds run: cloud Linux, local computer, or Android/Termux where supported.
4. Create a workspace using `scripts/scaffold.py`. Never point it at a non-empty project directory.
5. Fill in `BRIEF.md`, `TEST-PLAN.md` and `SECURITY.md`.
6. Build a tiny vertical slice and prove the toolchain before expanding scope.
7. Run automated tests, review the release candidate and explicitly approve any push or publish action.
8. Install/open on a phone and record the verdict.

## Prompt to start a project

"Use Phone-to-Ship. Help me turn this idea into a one-page brief, acceptance criteria, target platforms, architecture options, risks and a first vertical slice. Do not modify files or install tools until I approve the plan. Do not commit, push, publish or spend money without separate explicit approval."
