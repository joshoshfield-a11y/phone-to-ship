# Troubleshooting playbook

Start with the smallest diagnostic step that can distinguish likely causes. Preserve logs and the last known-good artifact before changing the environment.

| Symptom | First checks | Safer next step |
|---|---|---|
| Build fails after environment reset | runtime/SDK versions, PATH, disk, persisted workspace | restore pinned toolchain; rebuild from lockfile |
| Disk full / ENOSPC | filesystem containing output and temp dirs, inode use | clean only known caches after review; move scratch to persistent disk |
| Dependency resolution differs | lockfile, package manager version, registry config | use frozen/locked install; avoid unreviewed upgrades |
| Android install rejected | package ID, version, ABI, signature, free space | inspect signing cert and install logs; preserve existing app data |
| App launches then closes | crash logs, missing assets, permissions, ABI | reproduce on device; isolate first failing startup stage |
| Remote deploy appears stale | deployment status, commit SHA, CDN/browser cache | verify remote artifact and deployment identity before redeploying |
| SSH connection fails | network/VPN, host/port, sshd state, host key, key permissions | test each layer; never weaken authentication as a shortcut |
| Transfer appears truncated | source/destination byte counts and SHA-256 | retry to a new filename and compare hashes |
| Package unexpectedly large | archive listing, duplicate assets, debug symbols, raw inputs | inspect contents; exclude only confirmed non-runtime files |

Never respond to an unclear failure with broad deletion, force push, credential changes or a production redeploy. Diagnose first and request approval for consequential repairs.
