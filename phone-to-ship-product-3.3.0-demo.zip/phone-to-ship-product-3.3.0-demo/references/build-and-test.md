# Build and test gates

## Reproducibility

- Commit dependency lockfiles and pin runtime/toolchain versions where practical.
- Record exact build commands and environment versions.
- Separate debug, staging and release configurations.
- Build from a clean checkout at least once before release.
- Keep generated artifacts outside source directories unless the framework requires otherwise.

## Web

Minimum gates: dependency install from lockfile; lint/typecheck where configured; unit tests; production build; static inspection of output; JS syntax check; browser smoke test for primary route and core flow. Check mobile viewport, keyboard/focus, loading/error/empty states, offline behavior if promised, and console/network errors.

## Android

Record JDK, Gradle wrapper, Android Gradle Plugin, compile/target SDK, build-tools, NDK, engine/plugin and ABI versions. Verify application ID, version code/name, permissions, exported components, network security config, backup behavior, cleartext traffic, signing certificate and artifact checksum. Test install, update-over-install, launch, background/resume, rotation/config changes, permission denial and uninstall. A signature mismatch may prevent update; test upgrade paths deliberately. Never include signing credentials in the repository or build logs.

## Games

Test startup, scene transitions, input, pause/resume, save/load, audio, asset loading, resolution/aspect ratios, frame pacing, memory and thermal behavior. Profile on low-, mid- and high-tier representative hardware when those tiers are claimed. Establish measurable budgets from actual target devices; do not reuse another project's frame, draw-call or memory limit as a universal rule.

## Security and privacy

Inspect package output for `.env`, private keys, tokens, credentials, local config, crash dumps, user data, debug endpoints and unnecessary source maps. Scan dependencies and licenses with appropriate tools. Validate user input and authorization on the server. Do not log secrets or personal data. Treat screenshots and build logs as potentially sensitive.

## Evidence report

For each check, record: command or manual procedure, environment, result, exit code, date, artifact/version, and evidence location. Mark unavailable checks as **not run**, not passed. A test suite passing does not establish app-store compliance or security certification.
