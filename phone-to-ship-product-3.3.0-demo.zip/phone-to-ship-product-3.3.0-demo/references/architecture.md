# Architecture and workflow

## Logical components

- **Control device:** phone used for requirements, approvals, monitoring, installation and real-device testing.
- **Build workspace:** persistent Linux/cloud/desktop environment containing source, toolchains, dependencies, tests and artifacts.
- **Version control:** source history, reviewable diffs, tags and rollback points.
- **Distribution:** web hosting, app stores, direct downloads or internal distribution. These are separate targets with separate approval gates.

These are roles, not mandatory vendors. Choose services based on user requirements, region, budget, data sensitivity and maintainability. The toolkit does not require any single AI provider, cloud host, source host, engine or package manager.

## Deployment shapes

1. **Phone + cloud workspace:** best when the phone is the primary interface and builds need more CPU/RAM.
2. **Phone + local computer:** best when local files, USB debugging or offline work matter.
3. **Phone-only:** suitable for lightweight editing, scripting and web work where the toolchain supports ARM/Android. Do not promise full native builds without verifying the required SDK and memory.

## Backend decision rule

Start with the simplest architecture that satisfies the brief. Add a backend only for a demonstrated need such as shared data, authenticated user state, trusted secrets, payments or server-side processing. Client-side code cannot safely hold private API keys or enforce payment/authorization rules. Document data flows, retention, access controls and operating costs.

## Release states

- **Draft:** requirements and scope are being defined.
- **Built:** artifact generated; functionality not yet fully verified.
- **Tested:** defined automated and manual checks passed; limitations documented.
- **Approved:** user explicitly authorized the named release action.
- **Published:** target platform confirms release/deployment.
- **Verified:** published artifact was opened/installed and its critical workflow checked on a representative device.

Do not collapse these states into the single word "shipped".
