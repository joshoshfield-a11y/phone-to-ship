# Release and distribution checklist

## Before publishing

- Confirm product name, version, release notes, support contact and privacy/data disclosures.
- Review third-party assets, fonts, libraries and AI-generated content terms.
- Confirm platform-specific age rating, content rating, export, tax and payout requirements.
- Verify pricing, regions, demo/full-product split and refund/support policies with the owner.
- Check account access, signing, domain ownership, billing and platform prerequisites early.
- Produce a release candidate report with artifact hash and known limitations.

## Web hosting

Confirm root directory, build command, output directory, environment variables, domain, redirects, headers, caching and rollback strategy. Never put secrets in client-side environment variables or static bundles. Deploy only after explicit approval; then verify platform status, HTTPS, routes, assets, mobile layout and the primary workflow from a real device.

## Android distribution

Build a release variant, inspect manifest and permissions, verify signing identity, test clean install and update, scan package contents, and retain secure signing-key backups. Never upload a debug build by accident. Store credentials in a secure local secret store and keep them out of logs and repositories. Verify store listing, screenshots, privacy disclosures, data safety forms, content rating and target API requirements against current platform documentation.

## Direct downloads / game portals

Check archive contents, executable permissions, platform instructions, checksums, version labels and uninstall steps. Review the public page visually. Do not alter pricing, listing copy, cover art, AI disclosures or visibility without explicit direction.

## Approval boundaries

A release may involve separate actions: create commit, push branch, merge, deploy, submit to review, publish listing, change price, send announcement. Obtain approval for each action. Verify the exact destination and artifact before proceeding.
