# Phone-to-workspace connection patterns

## Choose a connection

- **SSH over a private network/VPN:** flexible shell access to a persistent workspace or phone-hosted Termux service.
- **Browser IDE/cloud workspace:** avoids managing inbound SSH and works well from mobile browsers.
- **Git-based handoff:** phone edits/approves issues and diffs; build workspace pulls only after explicit authorization.
- **USB debugging/ADB:** useful for device installation, logs and screen capture when a trusted computer is available. It is not a substitute for a secure remote shell.

## Secure SSH checklist

1. Install SSH from a trusted package source on both endpoints.
2. Use key-based authentication; disable password login where operationally safe.
3. Restrict network exposure to a private network or trusted LAN; do not expose SSH publicly without a hardened design.
4. Use least-privilege accounts and file permissions.
5. Verify host keys; do not blindly accept changed host fingerprints.
6. Keep private keys on the device that needs them; never paste keys into chat, tickets or source control.
7. Document startup after reboot and a safe recovery route.

## Termux notes

Termux is an Android terminal environment, not a full Linux distribution with unrestricted access to Android app data. Storage access requires the user's explicit Android permission and `termux-setup-storage`. Shared storage is not equivalent to another app's private data. Package availability and ABI support vary; verify current Termux documentation and package versions before relying on a command.

## Transfer verification

For every artifact transfer, record source path, destination path, byte count and SHA-256. Compare hashes at both ends where possible. Confirm sufficient free storage before transfer/install. Avoid overwriting a known-good build until the new artifact is verified.
