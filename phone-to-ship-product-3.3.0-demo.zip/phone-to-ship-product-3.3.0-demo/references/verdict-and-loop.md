# Real-device verdict and iteration

## Test on the actual target

A desktop browser preview cannot establish mobile usability. Install/open the release on a representative phone and test the core workflow from a fresh start. Record device model, OS version, app/build version, network conditions and test date.

## Verdict form

- **First impression:** what happens in the first 30 seconds?
- **Core task:** can a new user complete the primary workflow without coaching?
- **Controls/layout:** touch targets, keyboard, scrolling, safe areas, orientation and readability.
- **Reliability:** startup, resume, offline/reconnect, persistence and error recovery.
- **Performance:** load time, frame pacing, memory, heat and battery where relevant.
- **Defects:** exact reproduction steps, expected result, actual result, severity, screenshots/logs.
- **Verdict:** Ship / Fix and re-release / Hold.
- **Next action:** one highest-value correction.

## Feedback triage

Separate observed facts from opinions and proposed solutions. Reproduce defects before changing behavior. Preserve contradictory feedback and product requirements in the decision log. Convert each confirmed defect into a regression test where practical.

## Release record

Keep the previous release artifact, manifest, test report, source tag and rollback instructions. Never delete a failed attempt that may contain useful evidence. Record what changed, why, how it was tested and what remains unknown.
