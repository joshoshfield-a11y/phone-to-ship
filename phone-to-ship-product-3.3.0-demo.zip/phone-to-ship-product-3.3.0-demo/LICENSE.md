# Phone-to-Ship — Free Demo License

Copyright (c) 2026 Taylor Christian Mattheisen (DOGBYTE). All rights reserved.

This is the free demo of Phone-to-Ship 3.3.0. Plain English, no
lawyer needed. If this ever conflicts with the law where you live,
the law wins.

## You may

- Install and use this free demo on your own machine.
- Use it for personal and commercial projects.
- Modify it for your own use.

## You may not

- Share, redistribute, resell, or give away the demo or your
  download link.
- Claim it as your own work, or sell it under another name.

## What the demo leaves out

Agent orchestration (`pts agents ...`) and Muse-loop AI import
(`pts ai ...`) are not included in the free demo. The full version
is $25 at https://buy.stripe.com/dRm28rbjx3VbeyR3Kj2wU00.

## Support

Best effort. Email dogsbarkdogsbyte@gmail.com and describe what
happened, including the version number and what you were doing.

## Warranty

Provided as-is, no warranty.

## The short version

Free demo, your machine only, don't pass it around. The full
version is $25.
