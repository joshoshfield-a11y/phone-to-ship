# Demo bad tree

Missing index.html on purpose, plus a leaked script file.
