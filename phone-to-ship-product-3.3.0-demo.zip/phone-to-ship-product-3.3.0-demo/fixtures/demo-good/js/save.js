/* Versioned saves with migrations. Corrupt/future saves fail closed, never wipe a good slot. */
SF.Save = (function () {
  var KEY = "one_shot_save_v1", VERSION = 1;
  function key() { return (GAME.slug || "one-shot-game") + "_save_v" + VERSION; }
  function migrate(save) {
    // v1 is the first version; future bumps add: if (save.version < 2) { ...; save.version = 2; }
    if (!save.version) save.version = 1;
    return save;
  }
  function saveData(data) {
    try { localStorage.setItem(key(), JSON.stringify(data)); return true; }
    catch (e) { SF.toast("Save failed: storage full or blocked."); return false; }
  }
  function load() {
    try {
      var raw = localStorage.getItem(key());
      if (!raw) return null;
      var data = JSON.parse(raw);
      data = migrate(data);
      return data;
    } catch (e) { SF.toast("Save could not be read. Starting fresh will not delete other slots."); return null; }
  }
  return { save: saveData, load: load, VERSION: VERSION, key: key };
})();
