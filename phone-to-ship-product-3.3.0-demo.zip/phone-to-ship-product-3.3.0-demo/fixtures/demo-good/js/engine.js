/* ENGINE ONLY. No game-specific balance or story here; that lives in data.js. */
var SF = (function () {
  var canvas, ctx, W = 960, H = 540;
  var keys = {}, input = { x: 0, y: 0, action: false, interact: false };
  var entities = [], particles = [], projectiles = [];
  var camera = { x: 0, y: 0, trauma: 0 };
  var state = "TITLE", modalOpen = false, lastTime = 0, acc = 0;
  var sprites = {}, anims = {};
  var tileSize = 32;

  function el(id) { return document.getElementById(id); }
  function toast(msg) { var t = el("toast"); if (t) t.textContent = msg; }

  // --- Loaders with procedural fallbacks (never throw on a miss) ---
  function loadSprite(kind, id) {
    var key = kind + "/" + id;
    if (sprites[key]) return sprites[key];
    var img = new Image();
    img.onerror = function () { sprites[key] = null; };
    img.src = "assets/sprites/" + key + ".png";
    sprites[key] = img;
    return img;
  }
  function drawSpriteOrFallback(e) {
    var img = e.sprite ? loadSprite(e.spriteKind || "characters", e.sprite) : null;
    if (img && img.complete && img.naturalWidth) {
      ctx.drawImage(img, e.x - camera.x - e.w / 2, e.y - camera.y - e.h / 2, e.w, e.h);
    } else {
      ctx.fillStyle = e.colour || "#38bdf8";
      ctx.fillRect(e.x - camera.x - e.w / 2, e.y - camera.y - e.h / 2, e.w, e.h);
      ctx.fillStyle = "#0a1226"; ctx.font = "bold 14px sans-serif"; ctx.textAlign = "center";
      ctx.fillText((e.name || "?").charAt(0), e.x - camera.x, e.y - camera.y + 5);
    }
  }
  function Animations() {}
  Animations.play = function (entity, name) {
    // Manifest-driven in a full build (animations.json); one-shot floor:
    // procedural bob / squash via entity.animTime, never a frozen frame.
    entity.anim = name; entity.animTime = (entity.animTime || 0) + 1 / 60;
  };

  // --- Tilemap ---
  var world = { rows: [], width: 0, height: 0 };
  function loadMap(area) {
    world.rows = area.map; world.height = area.map.length; world.width = area.map[0].length;
    entities = [];
    area.map.forEach(function (row, y) {
      for (var x = 0; x < row.length; x++) {
        var c = row[x], px = x * tileSize + tileSize / 2, py = y * tileSize + tileSize / 2;
        if (c === "P") entities.push(makePlayer(px, py));
        if (c === "E") entities.push(makeEnemy(px, py));
        if (c === "N") entities.push(makeNpc(px, py));
        if (c === "$") entities.push({ kind: "pickup", id: "ore", x: px, y: py, w: 20, h: 20, colour: "#eab308", name: "Ore" });
      }
    });
  }
  function isSolid(tx, ty) {
    if (ty < 0 || ty >= world.height || tx < 0 || tx >= world.width) return true;
    return world.rows[ty][tx] === "#";
  }
  function solidAt(x, y) { return isSolid(Math.floor(x / tileSize), Math.floor(y / tileSize)); }

  function makePlayer(x, y) {
    var p = GAME.player;
    return { kind: "player", name: p.name, x: x, y: y, vx: 0, vy: 0, w: 28, h: 28,
      hp: p.hp, maxHp: p.hp, speed: p.speed, damage: p.damage, colour: "#38bdf8", sprite: "player" };
  }
  function makeEnemy(x, y) {
    var e = GAME.enemies[0];
    return { kind: "enemy", id: e.id, name: e.name, x: x, y: y, vx: 0, vy: 0, w: 26, h: 26,
      hp: e.hp, maxHp: e.hp, speed: e.speed, damage: e.damage, behaviour: e.behaviour, colour: e.colour, sprite: "enemy" };
  }
  function makeNpc(x, y) {
    var n = GAME.npcs[0];
    return { kind: "npc", id: n.id, name: n.name, x: x, y: y, w: 26, h: 26, colour: "#22c55e", sprite: "npc", dialogue: n.dialogue };
  }
  function player() { return entities.filter(function (e) { return e.kind === "player"; })[0]; }

  function spawnParticles(x, y, colour, n) {
    if (particles.length > 512) return;
    for (var i = 0; i < (n || 8); i++)
      particles.push({ x: x, y: y, vx: (Math.random() - 0.5) * 160, vy: (Math.random() - 0.5) * 160, life: 0.4, colour: colour });
  }
  function shake(amount) {
    if (GAME.settings && GAME.settings.reducedMotion) return;
    camera.trauma = Math.min(1, camera.trauma + amount);
  }

  function update(dt) {
    if (state !== "PLAYING" || modalOpen) return;
    var p = player(); if (!p) return;
    var sp = p.speed;
    p.vx = input.x * sp; p.vy = input.y * sp;
    if (GAME.physics === "platformer") { p.vy += 1400 * dt; }
    var nx = p.x + p.vx * dt, ny = p.y + p.vy * dt;
    if (!solidAt(nx, p.y)) p.x = nx;
    if (!solidAt(p.x, ny)) p.y = ny;
    if (GAME.physics === "platformer" && solidAt(p.x, p.y + p.h / 2 + 2)) p.vy = 0;
    Animations.play(p, (p.vx || p.vy) ? "walk" : "idle");
    entities.forEach(function (e) {
      if (e.kind !== "enemy") return;
      var dx = p.x - e.x, dy = p.y - e.y, d = Math.hypot(dx, dy) || 1;
      if (e.behaviour === "chase" && d < 300) { e.x += dx / d * e.speed * dt; e.y += dy / d * e.speed * dt; }
      if (d < 34 && p.hp > 0) { p.hp -= e.damage * dt; spawnParticles(p.x, p.y, "#ef4444", 1); }
      if (e.hp <= 0) return;
    });
    // projectiles
    projectiles.forEach(function (pr) {
      pr.x += pr.vx * dt; pr.y += pr.vy * dt; pr.life -= dt;
      entities.forEach(function (e) {
        if (e.kind === "enemy" && Math.hypot(e.x - pr.x, e.y - pr.y) < 24) {
          e.hp -= pr.damage; spawnParticles(e.x, e.y, "#f59e0b", 6);
          if (typeof SF.onEnemyHit === "function") SF.onEnemyHit(e);
          pr.life = 0;
        }
      });
    });
    projectiles = projectiles.filter(function (pr) { return pr.life > 0; });
    entities = entities.filter(function (e) { return !(e.kind === "enemy" && e.hp <= 0); });
    // pickups
    entities.forEach(function (e) {
      if (e.kind === "pickup" && Math.hypot(e.x - p.x, e.y - p.y) < 28) {
        e.taken = true;
        if (typeof SF.onPickup === "function") SF.onPickup(e);
      }
    });
    entities = entities.filter(function (e) { return !e.taken; });
    particles.forEach(function (pt) { pt.x += pt.vx * dt; pt.y += pt.vy * dt; pt.life -= dt; });
    particles = particles.filter(function (pt) { return pt.life > 0; });
    camera.x = Math.max(0, Math.min(world.width * tileSize - W, p.x - W / 2));
    camera.y = Math.max(0, Math.min(world.height * tileSize - H, p.y - H / 2));
    if (camera.trauma > 0) camera.trauma = Math.max(0, camera.trauma - dt * 2);
    if (typeof SF.onTick === "function") SF.onTick(p);
  }

  function draw() {
    if (!ctx) return;
    ctx.clearRect(0, 0, W, H);
    var shX = camera.trauma > 0 ? (Math.random() - 0.5) * camera.trauma * 12 : 0;
    var shY = camera.trauma > 0 ? (Math.random() - 0.5) * camera.trauma * 12 : 0;
    ctx.save(); ctx.translate(-shX, -shY);
    for (var y = 0; y < world.height; y++) for (var x = 0; x < world.width; x++) {
      var sx = x * tileSize - camera.x, sy = y * tileSize - camera.y;
      if (sx < -tileSize || sy < -tileSize || sx > W || sy > H) continue; // culling
      ctx.fillStyle = world.rows[y][x] === "#" ? "#334155" : "#1e293b";
      ctx.fillRect(sx, sy, tileSize, tileSize);
    }
    entities.forEach(drawSpriteOrFallback);
    projectiles.forEach(function (pr) { ctx.fillStyle = "#fde047"; ctx.fillRect(pr.x - camera.x - 4, pr.y - camera.y - 4, 8, 8); });
    particles.forEach(function (pt) { ctx.fillStyle = pt.colour; ctx.fillRect(pt.x - camera.x - 2, pt.y - camera.y - 2, 4, 4); });
    ctx.restore();
    if (state === "TITLE") {
      ctx.fillStyle = "#e8eefc"; ctx.font = "bold 42px sans-serif"; ctx.textAlign = "center";
      ctx.fillText(GAME.title, W / 2, H / 2 - 20);
      ctx.font = "18px sans-serif"; ctx.fillText("Press NEW GAME", W / 2, H / 2 + 20);
    }
  }

  function loop(t) {
    requestAnimationFrame(loop);
    var dt = Math.min(0.1, (t - lastTime) / 1000 || 0); lastTime = t;
    acc += dt; var steps = 0;
    while (acc >= 1 / 60 && steps < 3) { update(1 / 60); acc -= 1 / 60; steps++; }
    if (steps === 3) acc = 0;
    draw();
  }

  function init() {
    canvas = el("game"); ctx = canvas.getContext("2d");
    tileSize = GAME.tileSize || 32;
    window.addEventListener("keydown", function (e) {
      keys[e.key.toLowerCase()] = true;
      if (e.key === " ") input.action = true;
      if (e.key.toLowerCase() === "e") input.interact = true;
      if (e.key.toLowerCase() === "q" && typeof SF.onQuestKey === "function") SF.onQuestKey();
      if (e.key === "Escape" && typeof SF.onPauseKey === "function") SF.onPauseKey();
      updateInputFromKeys();
    });
    window.addEventListener("keyup", function (e) { keys[e.key.toLowerCase()] = false; updateInputFromKeys(); });
    function updateInputFromKeys() {
      input.x = (keys["d"] || keys["arrowright"] ? 1 : 0) - (keys["a"] || keys["arrowleft"] ? 1 : 0);
      input.y = (keys["s"] || keys["arrowdown"] ? 1 : 0) - (keys["w"] || keys["arrowup"] ? 1 : 0);
    }
    var btn = el("btn-action"); if (btn) btn.addEventListener("click", function () { input.action = true; });
    var bi = el("btn-interact"); if (bi) bi.addEventListener("click", function () { input.interact = true; });
    requestAnimationFrame(loop);
  }
  function fire() {
    var p = player(); if (!p) return;
    var dir = input.x || input.y ? { x: input.x, y: input.y } : { x: 1, y: 0 };
    var d = Math.hypot(dir.x, dir.y) || 1;
    projectiles.push({ x: p.x, y: p.y, vx: dir.x / d * 420, vy: dir.y / d * 420, damage: p.damage, life: 1.2 });
    if (typeof SF.Audio !== "undefined" && SF.Audio.sfx) SF.Audio.sfx("shoot");
  }

  return { init: init, loadMap: loadMap, entities: function () { return entities; }, player: player,
    state: function (s) { if (s) state = s; return state; }, modal: function (v) { if (v !== undefined) modalOpen = v; return modalOpen; },
    input: input, toast: toast, fire: fire, spawnParticles: spawnParticles, shake: shake,
    Animations: Animations, setState: function (s) { state = s; } };
})();
