/* GAME WIRING: HUD, menus, dialogue, quests, shop, saves, achievements, win/lose.
   This is the file a one-shot build fills from game.json; engine.js stays generic. */
(function () {
  var money = GAME.currency.start, ore = 0, questProgress = 0, questDone = false;
  var achievements = {}, settings = GAME.settings || {};
  var dialogueOpen = false;

  function $ (id) { return document.getElementById(id); }
  function hud() {
    var p = SF.player();
    if ($("hud-hp")) $("hud-hp").textContent = p ? "HP " + Math.max(0, Math.ceil(p.hp)) : "HP -";
    if ($("hud-money")) $("hud-money").textContent = GAME.currency.name + " " + money + " | ore " + ore;
    if ($("hud-quest")) $("hud-quest").textContent = questDone ? "Quest complete!" : "Quest: " + ore + "/" + GAME.quests[0].count + " ore";
    if ($("hud-area")) $("hud-area").textContent = GAME.areas[0].name;
  }
  function unlock(id) {
    if (!achievements[id]) {
      achievements[id] = true;
      var a = GAME.achievements.filter(function (x) { return x.id === id; })[0];
      if (a) SF.toast("Achievement: " + a.name);
    }
  }
  function showDialogue(npc) {
    dialogueOpen = true; SF.modal(true);
    var box = $("dialogue"); box.classList.remove("hidden");
    var node = npc.dialogue[0];
    $("dialogue-text").textContent = npc.name + ": " + node.text;
    var ch = $("dialogue-choices"); ch.innerHTML = "";
    (node.choices || []).forEach(function (c) {
      var b = document.createElement("button"); b.textContent = c.text;
      b.onclick = function () { closeDialogue(); };
      ch.appendChild(b);
    });
  }
  function closeDialogue() {
    dialogueOpen = false; SF.modal(false);
    $("dialogue").classList.add("hidden");
  }
  function openShop() {
    // ONE sell path per item kind, payout shown before confirming (ore lesson).
    var msg = "SHOP — Buy: " + GAME.shop.map(function (s) { return s.name + " " + s.price + "c"; }).join(" | ") +
      ". Sell: ore " + ore + " x 5c = " + (ore * 5) + "c. (Demo shop: press ACTION to sell all ore.)";
    SF.toast(msg);
    if (SF.input.action) { money += ore * 5; ore = 0; SF.input.action = false; }
  }
  function startGame(fresh) {
    SF.loadMap(GAME.areas[0]);
    if (fresh) { money = GAME.currency.start; ore = 0; questProgress = 0; questDone = false; }
    SF.setState("PLAYING");
    SF.toast(GAME.story.hook);
    if (SF.Audio) SF.Audio.playMusic("gameplay");
    renderMenu();
  }
  function renderMenu() {
    var m = $("menu"); if (!m) return;
    m.innerHTML = "";
    var ng = document.createElement("button"); ng.textContent = GAME.strings["menu.new_game"];
    ng.onclick = function () { startGame(true); };
    var cont = document.createElement("button"); cont.textContent = GAME.strings["menu.continue"];
    cont.onclick = function () {
      var s = SF.Save.load();
      if (s) { money = s.money; ore = s.ore; questDone = s.questDone; startGame(false); }
      else SF.toast("No save found — starting fresh."); startGame(true);
    };
    var pause = document.createElement("button"); pause.textContent = "PAUSE";
    pause.onclick = function () { SF.modal(!SF.modal()); SF.toast(SF.modal() ? "Paused" : "Resumed"); };
    var shop = document.createElement("button"); shop.textContent = "SHOP";
    shop.onclick = openShop;
    m.appendChild(ng); m.appendChild(cont); m.appendChild(pause); m.appendChild(shop);
  }
  function saveNow() {
    var ok = SF.Save.save({ version: SF.Save.VERSION, money: money, ore: ore, questDone: questDone, achievements: achievements });
    if (ok) SF.toast("Saved.");
  }

  SF.onPickup = function (e) {
    if (e.id === "ore") { ore++; unlock("first_pickup"); SF.Audio.sfx("pickup"); }
    if (ore >= GAME.quests[0].count && !questDone) {
      questDone = true; money += GAME.quests[0].reward; unlock("first_quest");
      SF.toast(GAME.strings["quest.complete"] + " +" + GAME.quests[0].reward + "c. Return to the Keeper, then find the boss.");
      SF.Audio.sfx("quest");
    }
  };
  SF.onEnemyHit = function (e) {
    SF.Audio.sfx("hit");
    if (e.hp <= 0) SF.toast(e.name + " defeated.");
  };
  SF.onQuestKey = function () { SF.toast(GAME.quests[0].hint); };
  SF.onPauseKey = function () { SF.modal(!SF.modal()); };
  SF.onTick = function (p) {
    hud();
    if (SF.input.action) { SF.fire(); SF.input.action = false; }
    if (SF.input.interact) {
      SF.input.interact = false;
      var npc = SF.entities().filter(function (e) { return e.kind === "npc" && Math.hypot(e.x - p.x, e.y - p.y) < 60; })[0];
      if (npc) showDialogue(npc); else openShop();
    }
    if (p.hp <= 0) {
      SF.setState("GAMEOVER"); SF.toast(GAME.strings["game.lose"]);
      setTimeout(function () { startGame(true); }, 2000);
    }
    // Win: quest done + all enemies cleared (one-shot win condition, stated in README).
    var enemiesLeft = SF.entities().filter(function (e) { return e.kind === "enemy"; }).length;
    if (questDone && enemiesLeft === 0 && SF.state() === "PLAYING") {
      SF.setState("VICTORY"); unlock("boss_down"); SF.toast(GAME.strings["game.win"] + " " + GAME.story.ending);
    }
    // Autosave on quest completion is wired via saveNow on visibility change below.
  };
  document.addEventListener("visibilitychange", function () {
    if (document.hidden && SF.state() === "PLAYING") saveNow();
  });
  var dc = $("dialogue-close"); if (dc) dc.onclick = closeDialogue;
  var bp = $("btn-pause"); if (bp) bp.onclick = function () { SF.modal(!SF.modal()); };

  window.addEventListener("load", function () { SF.init(); renderMenu(); hud(); });
  // Expose for headless smoke checks (node --check does not run this, but a browser harness can).
  window.__GAME_STATE__ = function () { return { money: money, ore: ore, questDone: questDone, state: SF.state() }; };
})();
