/* DATA ONLY. Edit this file to change the game; do not edit engine.js for balance/story.
   Generated from game.json by scripts/scaffold.py. */
var GAME = {
  title: "One-Shot Game", slug: "one-shot-game", seed: 20261104,
  genre: "topdown", physics: "topdown", tileSize: 32,
  palette: ["#0a1226", "#22c55e", "#eab308", "#ef4444", "#38bdf8", "#f59e0b"],
  player: { name: "Hero", speed: 220, hp: 100, weapon: "Blaster", damage: 12 },
  currency: { name: "credits", start: 60 },
  areas: [
    { id: "start", name: "Starting Area", biome: "plains", danger: 1,
      map: [
        "####################",
        "#..................#",
        "#..P.......E.......#",
        "#..........N.......#",
        "#....$.......$.....#",
        "#..................#",
        "####################"
      ] }
  ],
  // Legend: # wall, . floor, P player spawn, E enemy spawn, N NPC, $ pickup
  enemies: [
    { id: "grunt", name: "Grunt", hp: 30, speed: 90, damage: 8, behaviour: "chase", colour: "#ef4444" }
  ],
  boss: { id: "boss", name: "Final Foe", hp: 200, speed: 70, damage: 15, colour: "#a855f7" },
  items: [
    { id: "ore", name: "Ore", kind: "pickup", value: 5 },
    { id: "medkit", name: "Medkit", kind: "consumable", value: 25 }
  ],
  npcs: [
    { id: "keeper", name: "Keeper", role: "quest",
      dialogue: [
        { text: "Welcome, traveller. Collect 3 ore and return to me.",
          choices: [{ text: "I'll do it.", next: 1 }, { text: "Not now.", next: -1 }] },
        { text: "Good luck out there.", choices: [] }
      ] }
  ],
  quests: [
    { id: "q1", kind: "collect", giver: "keeper", target: "ore", count: 3, reward: 100,
      name: "First Delivery", hint: "Collect ore in the Starting Area and return to the Keeper." }
  ],
  shop: [
    { id: "medkit", name: "Medkit", price: 20 },
    { id: "sword", name: "Stronger Weapon (+6 damage)", price: 60 }
  ],
  story: { hook: "A hero arrives in a troubled land.", goal: "Gather strength and face the Final Foe.",
    obstacle: "Grunt patrols block the way.", twist: "The Keeper knew all along.", ending: "Peace returns." },
  strings: {
    "menu.new_game": "NEW GAME", "menu.continue": "CONTINUE", "menu.pause": "PAUSE",
    "quest.complete": "Quest complete!", "game.win": "You win!", "game.lose": "Game over — try again."
  },
  achievements: [
    { id: "first_pickup", name: "First Pickup", desc: "Pick up your first item." },
    { id: "first_quest", name: "First Quest", desc: "Complete your first quest." },
    { id: "boss_down", name: "Boss Down", desc: "Defeat the Final Foe." }
  ],
  settings: { quality: "balanced", musicVolume: 0.7, sfxVolume: 0.8, reducedMotion: false, textSize: 16 }
};
