/* Audio: file assets first, procedural synth fallback always. A missing file never throws. */
SF.Audio = (function () {
  var ctx = null, musicEl = null, muted = false;
  function ac() {
    if (!ctx) { try { ctx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { ctx = null; } }
    return ctx;
  }
  function tone(freq, dur, type, gain) {
    var c = ac(); if (!c || muted) return;
    var o = c.createOscillator(), g = c.createGain();
    o.type = type || "square"; o.frequency.value = freq;
    g.gain.setValueAtTime(gain || 0.08, c.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + dur);
    o.connect(g); g.connect(c.destination); o.start(); o.stop(c.currentTime + dur);
  }
  function playMusic(id) {
    try {
      if (!musicEl) musicEl = new Audio();
      musicEl.src = "assets/audio/music/" + id + ".ogg";
      musicEl.loop = true; musicEl.volume = (GAME.settings && GAME.settings.musicVolume) || 0.7;
      var p = musicEl.play(); if (p && p.catch) p.catch(function () { /* autoplay blocked: visuals cover it */ });
    } catch (e) { /* fallback is silence until first gesture; never a crash */ }
  }
  function sfx(id) {
    var map = { shoot: [880, 0.08, "square"], hit: [220, 0.1, "sawtooth"], pickup: [1320, 0.12, "sine"], ui: [660, 0.05, "sine"], quest: [523, 0.15, "sine"] };
    if (map[id]) tone(map[id][0], map[id][1], map[id][2]);
    else tone(440, 0.08, "square");
  }
  function voice(id) { /* subtitles carry the line; audio file optional */ sfx("ui"); }
  return { playMusic: playMusic, sfx: sfx, voice: voice, tone: tone };
})();
