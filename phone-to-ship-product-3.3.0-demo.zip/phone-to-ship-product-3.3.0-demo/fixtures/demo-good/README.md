# Demo good tree

A small playable web tree used only for self-test. Not a shipped game.
