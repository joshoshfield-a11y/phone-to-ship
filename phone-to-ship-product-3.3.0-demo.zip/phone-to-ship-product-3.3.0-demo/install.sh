#!/usr/bin/env bash
# Safe, repeatable install/upgrade. Usage: ./install.sh [PREFIX]
# Default PREFIX is $HOME/.local; set PTS_PREFIX to override.
# Fresh install or upgrade over an existing install:
#   - detects the installed version and prints it,
#   - stages the new tree and validates it (templates + py_compile)
#     before touching the old one,
#   - backs up the old tree before replacing it,
#   - swaps in the new tree, re-runs the full self-test on the
#     installed copy, and restores the backup if that test fails.
# Re-running install.sh on an already-installed copy is idempotent:
# it stages, validates, swaps, and self-tests again.
# An older install at $PREFIX/share/phone-to-ship (the 3.0.0 path) is
# NOT touched by this installer: it is a different directory, and its
# own uninstall.sh removes it. A notice is printed when one is found.
set -Eeuo pipefail
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
PREFIX="${1:-${PTS_PREFIX:-$HOME/.local}}"
case "$PREFIX" in ""|/|"$HOME"|"$HOME/..") echo "Refusing unsafe prefix: $PREFIX" >&2; exit 2;; esac
mkdir -p "$PREFIX/share" "$PREFIX/bin"
SHARE="$PREFIX/share"
DEST="$SHARE/phone-to-ship-product"
BIN="$PREFIX/bin/pts"
STAGE="$SHARE/.phone-to-ship.stage.$$"
BACKUP="$SHARE/.phone-to-ship.backup.$$"
cleanup(){ rm -rf -- "$STAGE"; if [[ -n "${CFILE:-}" ]]; then rm -f -- "$CFILE"; fi; if [[ -d "$BACKUP" && ! -e "$DEST" ]]; then mv -- "$BACKUP" "$DEST"; fi; }
trap cleanup EXIT
if ! command -v python3 >/dev/null 2>&1; then echo "python3 is required." >&2; exit 1; fi
if [[ -e "$BIN" && ! -L "$BIN" ]]; then echo "Refusing to replace non-symlink command: $BIN" >&2; exit 2; fi
if [[ -L "$BIN" ]]; then
  TARGET="$(readlink "$BIN")"
  case "$TARGET" in "$DEST/bin/pts") ;; *) echo "Refusing to replace unrelated symlink: $BIN -> $TARGET" >&2; exit 2;; esac
fi
NEW_VERSION="$(cat "$SRC/VERSION" 2>/dev/null || echo unknown)"
if [[ -f "$DEST/VERSION" ]]; then
  OLD_VERSION="$(cat "$DEST/VERSION")"
  echo "Upgrading phone-to-ship $OLD_VERSION -> $NEW_VERSION"
else
  echo "Fresh install of phone-to-ship $NEW_VERSION"
fi
if [[ -d "$SHARE/phone-to-ship" ]]; then
  echo "Note: an older install exists at $SHARE/phone-to-ship (3.0.0 path). This installer does not manage it; remove it with its own uninstall.sh if you no longer need it."
fi
mkdir "$STAGE"
# Do not use cp -a here: it tries to preserve ownership and fails in
# sandboxes that cannot chown. Plain cp -R copies content only.
cp -R "$SRC/." "$STAGE/"
chmod +x "$STAGE/bin/pts" "$STAGE/install.sh" "$STAGE/uninstall.sh" "$STAGE/scripts/"*.py "$STAGE/scripts/ci-check.sh" 2>/dev/null || true
# Pre-swap gate: templates + syntax must be clean before the old
# tree is touched. py_compile writes its bytecode to a temp file
# (it refuses /dev/null as a target), which cleanup removes, so the
# staged tree stays free of __pycache__. Recursive: a flat
# scripts/*.py glob would silently skip any sub-packages
# (the full version's scripts/ai/ and scripts/agents/).
"$STAGE/bin/pts" validate
CFILE="$(mktemp)"
for py in $(find "$STAGE/scripts" -name '*.py' | sort); do python3 -c 'import py_compile, sys; py_compile.compile(sys.argv[1], cfile=sys.argv[2], doraise=True)' "$py" "$CFILE"; done
if [[ -d "$DEST" ]]; then mv -- "$DEST" "$BACKUP"; fi
mv -- "$STAGE" "$DEST"
ln -sfn "$DEST/bin/pts" "$BIN"
# Post-install gate: the full suite runs on the installed copy, with
# bytecode writing off so the install stays clean. PTS_SELF_TEST_DEPTH
# is incremented so the nested suite run skips the install-touching
# tests (termux-check, upgrade, build gate) — they would recurse back
# into this installer. On failure the backup is restored (or the link
# removed on a fresh install) and the install is refused.
if ! PYTHONDONTWRITEBYTECODE=1 PTS_SELF_TEST_DEPTH=$(( ${PTS_SELF_TEST_DEPTH:-0} + 1 )) "$BIN" self-test; then
  echo "Post-install self-test FAILED; restoring the previous install." >&2
  rm -rf -- "$DEST"
  if [[ -d "$BACKUP" ]]; then mv -- "$BACKUP" "$DEST"; ln -sfn "$DEST/bin/pts" "$BIN"; else rm -f -- "$BIN"; fi
  rm -f -- "$CFILE"
  trap - EXIT
  exit 1
fi
rm -rf -- "$BACKUP"
rm -f -- "$CFILE"
trap - EXIT
"$BIN" version
echo "Installed/updated Phone-to-Ship $NEW_VERSION at $DEST"
echo "Ensure $PREFIX/bin is on PATH."
