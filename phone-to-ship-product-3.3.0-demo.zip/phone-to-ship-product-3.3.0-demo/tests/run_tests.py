#!/usr/bin/env python3
"""Automated test suite for phone-to-ship product. Exit 0 = all pass.
Usage: run_tests.py --product <product-root> [--pts <pts-path>]
Tests, in order (merged 3.0.0 + 1.2.0 + 3.1.0 + 3.2.0 + 3.3.0):
1 validate_templates: 0 fails
2 pts version: prints a version string
3 scaffold: creates a project with all working templates, and refuses a
  non-empty out dir with exit 2 without changing existing files
4 good tree: scaffold + demo-good fixture -> ship-check exit 0, 0 fails
5 bad tree: demo-bad fixture -> ship-check exit 1, fails name both
  missing index.html and the leaked .py file
6 package: package the good tree, MANIFEST bytes/sha256 match the files
  on disk, and no .py file is in the package
7 placeholder guard: the phone-push template with placeholders intact
  refuses to run and sends nothing
8 vercel.json in the scaffold parses as JSON
9 package refuses source/destination overlap and symlink inputs
10 secret scanner catches credential-shaped fixture without printing value
11 orchestrate good tree: exit 0, awaiting-approval, staged package
12 orchestrate bad tree: exit 1, needs-human, leak.py quarantined (not
    deleted), 1 repair attempt, missing index.html verbatim, no package
13 verdict: ship recorded on the awaiting-approval run; a second
    verdict is refused exit 2
14 verdict on a needs-human run is refused exit 2
15 orchestrate brief missing goal fails fast exit 2 naming goal
16 doctor: exit 0 with python/Termux report; exit 1 naming bash when
    bash is absent from PATH
17 snapshot/restore: round-trip restores hashes; a corrupt snapshot is
    refused exit 2 and the tree is left as-is
18 config: get/set valid keys; invalid key/value refused exit 2,
    nothing written
19 config max-repairs drives orchestrate: 0 means no repair attempts;
    --max-repairs 1 overrides the config default
20 structured logs: orchestrate writes log.jsonl with an event per
    stage, pts logs prints it, verdict appends verdict-recorded
21 termux-check: exit 0 (depth 0 only, see below)
22 upgrade-over-1.2.0: install 1.2.0 to a temp prefix, then install
    3.3.0-demo over it; version 3.3.0-demo, doctor passes. Plus rollback: a
    3.3.0-demo copy whose post-install self-test fails leaves the 1.2.0
    install intact (depth 0 only, see below)
23 build gate: build_package.py refuses to build when the suite fails
    (broken template copy -> nonzero exit, no zip) (depth 0 only)

Demo cut (3.3.0-demo): tests 24-35 (all ai + agents blocks) removed.
Reentrancy: install.sh and build_package.py invoke this suite after an
install / before a build. A nested run sets PTS_SELF_TEST_DEPTH >= 1,
and tests 21-23 are skipped there (they are the ones that invoke the
installer or the builder, and would recurse). Prints PASS/FAIL per test
with counts, not a bare pass. Depth 0 runs 25 checks; the build gate
(depth 1) runs 21.
"""
import argparse, hashlib, json, os, shutil, subprocess, sys, tempfile
from pathlib import Path

DEPTH = int(os.environ.get("PTS_SELF_TEST_DEPTH", "0"))

def run(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, **kw)

def sha256(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--product", required=True); ap.add_argument("--pts", default=None)
    args = ap.parse_args()
    root = Path(args.product).expanduser().resolve()
    pts = Path(args.pts).expanduser() if args.pts else root / "bin" / "pts"
    py = sys.executable
    results = []
    def check(name, ok, detail=""):
        results.append((name, ok, detail)); print(f"{'PASS' if ok else 'FAIL'}: {name} {detail}")
    with tempfile.TemporaryDirectory(prefix="pts-test-") as td:
        work = Path(td)
        # 1 validate
        r = run([py, str(root / "scripts" / "validate_templates.py"), "--skill", str(root)])
        check("validate_templates 0 fails", r.returncode == 0 and "FAIL: 0" in r.stdout, r.stdout.strip().splitlines()[-1] if r.stdout else "")
        # 2 version
        r = run([py, str(pts), "version"])
        check("pts version", r.returncode == 0 and r.stdout.strip() != "", r.stdout.strip())
        # 3 scaffold + refusal
        proj = work / "my-game"
        r = run([py, str(pts), "new", "--name", "My Game", "--out", str(proj), "--target", "web", "--target", "apk"])
        expected = ["BRIEF.md", "SHIPPING-CHECKLIST.md", "PHONE-VERDICT.md", "DECISION-LOG.md",
                    "TERMUX-MANUAL-STEPS.md", "phone-push.sh", "vercel.json", "README.md", "CHANGELOG.md"]
        check("scaffold creates all templates", r.returncode == 0 and all((proj / f).exists() for f in expected), f"missing={[f for f in expected if not (proj / f).exists()]}")
        before = {str(p.relative_to(proj)): sha256(p) for p in proj.rglob("*") if p.is_file()}
        r = run([py, str(pts), "new", "--name", "My Game", "--out", str(proj)])
        after = {str(p.relative_to(proj)): sha256(p) for p in proj.rglob("*") if p.is_file()}
        check("scaffold refuses non-empty dir exit 2, files untouched", r.returncode == 2 and before == after, f"exit={r.returncode}")
        # 4 good tree
        good = work / "good"
        shutil.copytree(root / "fixtures" / "demo-good", good)
        # merge scaffold templates into good tree too, as a real project would have them
        for f in proj.iterdir():
            if f.is_file(): shutil.copy2(f, good / f.name)
        r = run([py, str(pts), "check", "--tree", str(good)])
        check("good tree ship-check 0 fails", r.returncode == 0 and "FAIL: 0" in r.stdout, r.stdout.strip().splitlines()[-1] if r.stdout else "")
        # 5 bad tree
        bad = work / "bad"
        shutil.copytree(root / "fixtures" / "demo-bad", bad)
        r = run([py, str(pts), "check", "--tree", str(bad)])
        check("bad tree ship-check exit 1 with both fails", r.returncode == 1 and "missing required file: index.html" in r.stdout and "leak.py" in r.stdout, f"exit={r.returncode}")
        # 6 package + manifest match
        pkg = work / "pkg"
        r = run([py, str(pts), "package", "--tree", str(good), "--out", str(pkg), "--version", "v3.3.0-test"])
        manifest = json.loads((pkg / "MANIFEST.json").read_text()) if (pkg / "MANIFEST.json").exists() else {}
        manifest_ok = r.returncode == 0 and manifest.get("files", 0) > 0
        if manifest_ok:
            for e in manifest["entries"]:
                f = pkg / e["path"]
                if not f.exists() or f.stat().st_size != e["bytes"] or sha256(f) != e["sha256"]:
                    manifest_ok = False; break
            manifest_ok = manifest_ok and not any(e["path"].endswith(".py") for e in manifest["entries"])
            manifest_ok = manifest_ok and manifest["bytes"] == sum(e["bytes"] for e in manifest["entries"])
        check("package manifest matches files, no .py shipped", manifest_ok, f"files={manifest.get('files')} bytes={manifest.get('bytes')}")
        # 7 placeholder guard
        dummy = work / "dummy.apk"; dummy.write_bytes(b"test")
        r = run(["bash", str(proj / "phone-push.sh"), str(dummy)])
        check("phone-push template refuses with placeholders", r.returncode != 0 and "Stop:" in r.stdout + r.stderr, f"exit={r.returncode}")
        # 8 vercel json
        try:
            json.loads((proj / "vercel.json").read_text()); v_ok = True
        except Exception:
            v_ok = False
        check("scaffold vercel.json parses", v_ok)
        # 9 package refuses source/destination overlap and symlink inputs
        nested = work / "nested"; nested.mkdir()
        r = run([py, str(pts), "package", "--tree", str(good), "--out", str(good / "nested-out")])
        check("package refuses nested destination", r.returncode == 2)
        # 10 secret scanner catches credential-shaped fixture without printing value
        secret = work / "secret-tree"; secret.mkdir(); (secret / "index.html").write_text("<html></html>")
        (secret / "config.js").write_text("const api_key = \"example-secret-value-123456\";")
        r = run([py, str(pts), "check", "--tree", str(secret)])
        check("secret scan blocks credential-like assignment", r.returncode == 1 and "credential assignment" in r.stdout)
        # 11 orchestrate good tree
        brief = root / "fixtures" / "demo-brief.md"
        r = run([py, str(pts), "orchestrate", "--tree", str(good), "--brief", str(brief)])
        good_run = json.loads((good / ".pts" / "runs" / "index.json").read_text())["runs"][-1]["run_id"] if (good / ".pts" / "runs" / "index.json").exists() else None
        staged = good / ".pts" / "staged" / good_run if good_run else None
        check("orchestrate good tree awaiting-approval + staged package", r.returncode == 0 and "awaiting-approval" in r.stdout and staged is not None and (staged / "MANIFEST.json").exists(), f"exit={r.returncode} run={good_run}")
        # 12 orchestrate bad tree
        r = run([py, str(pts), "orchestrate", "--tree", str(bad), "--brief", str(brief)])
        bad_run = json.loads((bad / ".pts" / "runs" / "index.json").read_text())["runs"][-1]["run_id"] if (bad / ".pts" / "runs" / "index.json").exists() else None
        bad_ledger = json.loads((bad / ".pts" / "runs" / bad_run / "run.json").read_text()) if bad_run else {}
        quarantined = bad / ".pts" / "quarantine" / bad_run / "leak.py" if bad_run else None
        staged_bad = bad / ".pts" / "staged"
        no_package = (not staged_bad.exists()) or not list(staged_bad.glob("*"))
        check("orchestrate bad tree needs-human, leak quarantined, 1 repair", r.returncode == 1 and "needs-human" in r.stdout and "missing required file: index.html" in r.stdout and quarantined is not None and quarantined.exists() and not (bad / "leak.py").exists() and len(bad_ledger.get("repairs", [])) == 1 and no_package, f"exit={r.returncode} run={bad_run}")
        # 13 verdict on the good run, then a second verdict is refused
        r1 = run([py, str(pts), "verdict", "--tree", str(good), "--run", str(good_run), "--decision", "ship", "--note", "test verdict"])
        r2 = run([py, str(pts), "verdict", "--tree", str(good), "--run", str(good_run), "--decision", "ship"])
        check("verdict ship recorded, second verdict refused exit 2", r1.returncode == 0 and "ship" in r1.stdout and r2.returncode == 2, f"first={r1.returncode} second={r2.returncode}")
        # 14 verdict on the needs-human run is refused
        r = run([py, str(pts), "verdict", "--tree", str(bad), "--run", str(bad_run), "--decision", "ship"])
        check("verdict on needs-human run refused exit 2", r.returncode == 2, f"exit={r.returncode}")
        # 15 brief missing goal fails fast
        bad_brief = work / "brief-no-goal.md"
        bad_brief.write_text("Project: Demo Game\nTarget: web\n")
        r = run([py, str(pts), "orchestrate", "--tree", str(good), "--brief", str(bad_brief)])
        check("brief missing goal fails fast exit 2 naming goal", r.returncode == 2 and "goal" in (r.stdout + r.stderr).lower(), f"exit={r.returncode}")
        # 16 doctor
        r = run([py, str(pts), "doctor"])
        doc_ok = r.returncode == 0 and "doctor: OK" in r.stdout and "Termux environment:" in r.stdout
        env_nopath = dict(os.environ); env_nopath["PATH"] = "/nonexistent"
        r2 = run([py, str(pts), "doctor"], env=env_nopath)
        doc_ok = doc_ok and r2.returncode == 1 and "bash" in r2.stdout
        check("doctor OK normally, exit 1 naming bash with bash missing", doc_ok, f"normal={r.returncode} stripped={r2.returncode}")
        # 17 snapshot/restore round-trip + corrupt refusal
        snap_tree = work / "snap-tree"
        shutil.copytree(good, snap_tree, ignore=shutil.ignore_patterns(".pts"))
        orig_hash = sha256(snap_tree / "index.html")
        r = run([py, str(pts), "snapshot", "--tree", str(snap_tree)])
        # output: "snapshot <id>: N files, B bytes -> .pts/snapshots/<id>/"
        snap_id = r.stdout.strip().split()[1].rstrip(":") if r.returncode == 0 else None
        (snap_tree / "index.html").write_text("<html>CHANGED</html>")
        r2 = run([py, str(pts), "restore", "--tree", str(snap_tree), "--id", str(snap_id)])
        roundtrip_ok = r.returncode == 0 and snap_id and r2.returncode == 0 and sha256(snap_tree / "index.html") == orig_hash
        r3 = run([py, str(pts), "snapshots", "--tree", str(snap_tree)])
        roundtrip_ok = roundtrip_ok and snap_id in r3.stdout
        # corrupt one snapshot file, restore must refuse and leave the tree as-is
        (snap_tree / "index.html").write_text("<html>CHANGED AGAIN</html>")
        snap_file = snap_tree / ".pts" / "snapshots" / str(snap_id) / "index.html"
        snap_file.write_text("<html>CORRUPTED SNAPSHOT</html>")
        r4 = run([py, str(pts), "restore", "--tree", str(snap_tree), "--id", str(snap_id)])
        corrupt_ok = r4.returncode == 2 and (snap_tree / "index.html").read_text() == "<html>CHANGED AGAIN</html>"
        check("snapshot/restore round-trip + corrupt snapshot refused", roundtrip_ok and corrupt_ok, f"snap={snap_id} restore={r2.returncode} corrupt={r4.returncode}")
        # 18 config get/set + validation
        cfg_tree = work / "cfg-tree"; cfg_tree.mkdir()
        r1 = run([py, str(pts), "config", "--tree", str(cfg_tree), "set", "max-repairs", "3"])
        r2 = run([py, str(pts), "config", "--tree", str(cfg_tree), "get", "max-repairs"])
        r3 = run([py, str(pts), "config", "--tree", str(cfg_tree), "set", "target", "web,apk"])
        r4 = run([py, str(pts), "config", "--tree", str(cfg_tree), "get", "target"])
        r5 = run([py, str(pts), "config", "--tree", str(cfg_tree), "set", "bogus-key", "x"])
        r6 = run([py, str(pts), "config", "--tree", str(cfg_tree), "set", "max-repairs", "99"])
        r7 = run([py, str(pts), "config", "--tree", str(cfg_tree), "set", "target", "windows"])
        r8 = run([py, str(pts), "config", "--tree", str(cfg_tree), "set", "version", "banana"])
        r9 = run([py, str(pts), "config", "--tree", str(cfg_tree), "get", "no-such-key"])
        cfg_ok = (r1.returncode == 0 and r2.stdout.strip() == "3" and r3.returncode == 0 and r4.stdout.strip() == "web,apk"
                  and r5.returncode == 2 and r6.returncode == 2 and r7.returncode == 2 and r8.returncode == 2 and r9.returncode == 2)
        check("config get/set valid keys, invalid refused exit 2", cfg_ok, f"get={r2.stdout.strip()!r} refusals={[r5.returncode, r6.returncode, r7.returncode, r8.returncode, r9.returncode]}")
        # 19 config max-repairs drives orchestrate; CLI flag overrides it
        cfg_bad = work / "cfg-bad"; shutil.copytree(root / "fixtures" / "demo-bad", cfg_bad)
        run([py, str(pts), "config", "--tree", str(cfg_bad), "set", "max-repairs", "0"])
        r1 = run([py, str(pts), "orchestrate", "--tree", str(cfg_bad), "--brief", str(brief)])
        run1 = json.loads((cfg_bad / ".pts" / "runs" / "index.json").read_text())["runs"][-1]["run_id"]
        ledger1 = json.loads((cfg_bad / ".pts" / "runs" / run1 / "run.json").read_text())
        zero_repairs = r1.returncode == 1 and ledger1.get("repairs") == [] and (cfg_bad / "leak.py").exists()
        cfg_bad2 = work / "cfg-bad2"; shutil.copytree(root / "fixtures" / "demo-bad", cfg_bad2)
        run([py, str(pts), "config", "--tree", str(cfg_bad2), "set", "max-repairs", "0"])
        r2 = run([py, str(pts), "orchestrate", "--tree", str(cfg_bad2), "--brief", str(brief), "--max-repairs", "1"])
        run2 = json.loads((cfg_bad2 / ".pts" / "runs" / "index.json").read_text())["runs"][-1]["run_id"]
        ledger2 = json.loads((cfg_bad2 / ".pts" / "runs" / run2 / "run.json").read_text())
        one_repair = r2.returncode == 1 and len(ledger2.get("repairs", [])) == 1 and not (cfg_bad2 / "leak.py").exists()
        check("config max-repairs 0 = no repairs; --max-repairs 1 overrides", zero_repairs and one_repair, f"zero={ledger1.get('repairs')} one={len(ledger2.get('repairs', []))}")
        # 20 structured logs
        log_path = good / ".pts" / "runs" / good_run / "log.jsonl"
        log_ok = False
        if log_path.exists():
            events = [json.loads(l) for l in log_path.read_text().splitlines() if l.strip()]
            stages = [e["stage"] for e in events]
            log_ok = (all(set(e) >= {"ts", "stage", "event", "detail"} for e in events)
                      and all(s in stages for s in ["brief", "plan", "build", "test", "diagnose", "package", "approval-stop"])
                      and any(e["event"] == "verdict-recorded" for e in events))
            r = run([py, str(pts), "logs", "--tree", str(good), "--run", str(good_run)])
            log_ok = log_ok and r.returncode == 0 and "awaiting-approval" in r.stdout
        check("run log.jsonl has per-stage events; pts logs prints them", log_ok, f"events={len(events) if log_path.exists() else 0}")
        # 21 termux-check (depth 0 only)
        if DEPTH == 0:
            r = run([py, str(root / "scripts" / "termux-check.py"), "--product", str(root)])
            check("termux-check exit 0", r.returncode == 0, r.stdout.strip().splitlines()[-1] if r.stdout else "")
        else:
            print(f"SKIP: termux-check (nested run, depth {DEPTH})")
        # 22 upgrade over 1.2.0 (depth 0 only)
        if DEPTH == 0:
            tree120 = root.parent / "phone-to-ship-product-1.2.0"
            prefix = work / "upgrade-prefix"
            up_ok = False
            if tree120.exists():
                r1 = run(["bash", str(tree120 / "install.sh"), str(prefix)])
                v1 = run([py, str(prefix / "bin" / "pts"), "version"])
                r2 = run(["bash", str(root / "install.sh"), str(prefix)])
                v2 = run([py, str(prefix / "bin" / "pts"), "version"])
                d2 = run([py, str(prefix / "bin" / "pts"), "doctor"])
                up_ok = (r1.returncode == 0 and v1.stdout.strip() == "1.2.0"
                         and r2.returncode == 0 and "Upgrading phone-to-ship 1.2.0 -> 3.3.0-demo" in r2.stdout
                         and v2.stdout.strip() == "3.3.0-demo" and d2.returncode == 0)
                check("upgrade over 1.2.0: version 3.3.0-demo, doctor OK", up_ok, f"install120={r1.returncode} v1={v1.stdout.strip()!r} install320={r2.returncode} v2={v2.stdout.strip()!r}")
                # Rollback: on a separate prefix holding only 1.2.0, a
                # 3.3.0-demo copy whose post-install self-test fails must
                # leave the 1.2.0 install intact. Breaking
                # tests/run_tests.py is invisible to the pre-swap
                # gates (they validate templates + compile scripts/)
                # but fails the post-install self-test.
                prefix_rb = work / "rollback-prefix"
                run(["bash", str(tree120 / "install.sh"), str(prefix_rb)])
                broken310 = work / "broken310"
                shutil.copytree(root, broken310, ignore=shutil.ignore_patterns("__pycache__", ".pts"))
                (broken310 / "tests" / "run_tests.py").write_text(
                    "raise SystemExit(1)\n"
                    + (broken310 / "tests" / "run_tests.py").read_text())
                r3 = run(["bash", str(broken310 / "install.sh"), str(prefix_rb)])
                v3 = run([py, str(prefix_rb / "bin" / "pts"), "version"])
                rollback_ok = (r3.returncode == 1 and v3.stdout.strip() == "1.2.0")
                check("failed upgrade rolls back to 1.2.0", rollback_ok, f"install={r3.returncode} version={v3.stdout.strip()!r}")
            else:
                check("upgrade over 1.2.0: version 3.3.0-demo, doctor OK", False, "1.2.0 tree missing")
                check("failed upgrade rolls back to 1.2.0", False, "1.2.0 tree missing")
        else:
            print(f"SKIP: upgrade-over-1.2.0 (nested run, depth {DEPTH})")
        # 23 build gate refuses on a failing suite (depth 0 only)
        if DEPTH == 0:
            broken = work / "broken"
            shutil.copytree(root, broken, ignore=shutil.ignore_patterns("__pycache__", ".pts"))
            (broken / "assets" / "templates" / "vercel.json").write_text("{ not json")
            out_zip = work / "broken.zip"
            r = run([py, str(root / "scripts" / "build_package.py"), "--source", str(broken), "--version", "9.9.9-test", "--out", str(out_zip)])
            check("build_package refuses when the suite fails", r.returncode != 0 and not out_zip.exists(), f"exit={r.returncode}")
        else:
            print(f"SKIP: build gate (nested run, depth {DEPTH})")
    failed = [n for n, ok, _ in results if not ok]
    print(f"RESULT: {len(results)-len(failed)}/{len(results)} passed, FAIL: {len(failed)}")
    for n in failed: print(f"  failed: {n}")
    return 1 if failed else 0

if __name__ == "__main__":
    raise SystemExit(main())
